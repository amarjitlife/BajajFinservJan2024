/*
Compiling Java Source Code
	javac JavaBasics.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
	java -cp ClassFiles JavaBasics
*/

import java.util.Random;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Arrays;

//______________________________________________________________________

class HelloWorld {
	// Class Method :: Static Context
	public static void playWithHelloWorld() {
		System.out.println("Hello World!!!");
	}

	// Instance/Object Method :: Non-Static Context
	public void sayHello() {
		System.out.println("Hello Helloooooo!!!");		
	}
}

//______________________________________________________________________
// import java.util.Random;

class MethodDemo {
	public static void playWithInstanceMethods() {
		Random generator = new Random();

		System.out.println( generator.nextInt() );
		System.out.println( generator.nextInt() );
	}
}

//______________________________________________________________________

class NumberDemo {

	public static void playWithNumbers() {
	        System.out.println(4000000000L); 
	        System.out.println(0xCAFEBABE); 
	        System.out.println(0b1001); 
	        System.out.println(011); 

	        // Underscores in literals   
	        System.out.println(1_000_000_000); 
	        System.out.println(0b1111_0100_0010_0100_0000);        

	        // Default Type For Constant Literal 3.14 Is Double
	        //		Following Both Lines Are Equivalent
	        System.out.println(3.14); 
	        System.out.println(3.14D); 

	        // 3.14F Is Float Type Value
	        System.out.println(3.14F); 

	        // try {
		        System.out.println( 1.0 / 0.0 ); 
		        System.out.println( -1.0 / 0.0 ); 
		        System.out.println( 0.0 / 0.0 ); 
		    // } catch ( ArithmaticException ex ) { // BAD CODE
		    // 	// Hanlding Code
		    // }

	// Infinity
	// -Infinity
	// NaN
		// BAD CODE
	        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
	        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);
	        System.out.println(0.0 / 0.0 == Double.NaN);
	// true
	// true
	// false

	        // GOOD CODE
	        System.out.println(Double.isInfinite(1.0 / 0.0));
	        System.out.println(Double.isNaN(0.0 / 0.0));
	        System.out.println(Double.isFinite(0.0 / 0.0));

	        double x = 2.0;
	        double y = 1.1;

	        // BAD CODE
	        if ( x - y == 0.9 ) {
	 		// After Validation 
	        	System.out.println("\n Access Denied");
	        	return;
	        }
	        // } else {
	        	System.out.println("\n Access Allowed");
	        // }
	        
	        // Access To System Internal Services...

	        System.out.println('J'); 
	        System.out.println('J' == 74); 
	        System.out.println('\u004A'); 
	        System.out.println('\u263A'); 
	}


	public static int sum( int x, int y ) {
		return x + y;
	}

	public static void playWithSum() {
		int a = 2147483647;
		int b = 10;

		int result = 0;

		result = sum( a, b );
		System.out.println( "Result : " + result );

		a = -2147483648;
		b = -10;
		result = sum( a, b );
		System.out.println( "Result : " + result );
	}
}

//______________________________________________________________________

class VariableDemo {
    public final int DAYS_PER_YEAR = 365;
    
    enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };
    
    public static void playWithVariables() {
        int total = 0;
        int i = 0, count;
        Random generator = new Random();
        double lotsa$ = 1000000000.0; // Legal, but not a good idea
        double élévation = 0.0;
        double π = 3.141592653589793;
        String Count = "Dracula"; // Not the same as count
        int countOfInvalidInputs = 0; // Example of camelCase
        final int DAYS_PER_WEEK = 7;
        Weekday startDay = Weekday.MON;
        count = 111;
        // The following line would cause an error since count has not been initialized
        System.out.println(count); 

        String नमस = "नमस्ते";
        System.out.println( नमस );

    }
}


//______________________________________________________________________

 class ArithmeticDemo {
    public static void playWithOperators() {
        // Division and remainder
        
        System.out.println(17 / 5);
        System.out.println(17 % 5);
        System.out.println(Math.floorMod(17, 5));
        
        System.out.println(-17 / 5);
        System.out.println(-17 % 5);
        System.out.println(Math.floorMod(-17, 5));
        
        // Increment and decrement
        
        int[] a = { 17, 29 };
        int n = 0;
        System.out.printf("%d %d\n", a[n++], n); 
        n = 0;
        System.out.printf("%d %d\n", a[++n], n);
        
        // Powers and roots
        
        System.out.println(Math.pow(10, 9));
        System.out.println(Math.sqrt(1000000));
        
        // Number conversions
        
        double x = 42;
        System.out.println(x); // 42.0
        
        float f = 123456789;
        System.out.println(f); // 1.23456792E8
        
        x = 3.75;
        n = (int) x;
        System.out.println(n); // 3
        
        n = (int) Math.round(x); 
        System.out.println(n); // 4
        
        System.out.println('J' + 1); // 75
        char next = (char)('J' + 1); 
        System.out.println(next); // 'K'
        
        n = (int) 3000000000L; 
        System.out.println(n); // -1294967296
    }
}

//______________________________________________________________________

// import java.math.BigDecimal;
// import java.math.BigInteger;

class BigNumberDemo {
    public static void playWithBigNumbers() {
        BigInteger n = BigInteger.valueOf(876543210123456789L);
        BigInteger k = new BigInteger("9876543210123456789");
        BigInteger r = BigInteger.valueOf(5).multiply(n.add(k)); // r = 5 * (n + k)
        System.out.println(r);
        System.out.println(2.0 - 1.1);
        BigDecimal d = BigDecimal.valueOf(2, 0).subtract(BigDecimal.valueOf(11, 1));
        System.out.println(d);
    }
}

//______________________________________________________________________

class RelationalDemo {
    public static void playWithRelationalOperators() {
        int length = 10;
        int n = 7;
        System.out.println(0 <= n && n < length);
        
        // Short circuit evaluation
        int s = 30;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        n = 0;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        System.out.println(n == 0 || s + (1 - s) / n >= 50);
        
        int time = 7;
        System.out.println(time < 12 ? "am" : "pm");
    }
}

//______________________________________________________________________

// import java.time.ZoneId;
// import java.util.Arrays;

class StringDemo {
    public static void playWithString() {
        String location = "Java";
        String greeting = "Hello " + location;
        System.out.println(greeting);
        int age = 42;
        String output = age + " years";
        System.out.println(output);
        
        System.out.println("Next year, you will be " + age + 1); // Error
        System.out.println("Next year, you will be " + (age + 1)); // Ok

        // BEST PRACTICE
        //	Use Join APIs to Concatenate Multiple Strings
	String names = String.join(", ", "Peter", "Paul", "Mary");
        System.out.println(names);

        location = location + "More Java!!!";
        System.out.println( location );

        StringBuilder something = new StringBuilder();
        something.append("Hello!");
	something.append("Sweety!!!");

	System.out.println( something );
        something.append(" Alia Bhat!!!");
	System.out.println( something );
	System.out.println( something.length() );

	String omylife = something.toString();
	System.out.println( omylife );
	System.out.println( omylife.length() );

	String subSomething = something.substring(0, 20);
        System.out.println( subSomething );
        System.out.println( subSomething.length() );

        greeting = "Hello, World!";
        location = greeting.substring(7, 12);
        System.out.println(location); // World


        // Equality testing     
        System.out.println(location.equals("World")); 	// true
        // BAD CODE :: Never Compare Following
        //	Floating Points As Well Strings With Equality
        System.out.println(location == "World");  	// false
        
        System.out.println(location.equalsIgnoreCase("world"));
        System.out.println("word".compareTo("world"));

        // Converting between numbers and strings
        int n = 42;
        String str = Integer.toString(n, 2);
        System.out.println(str);

        n = Integer.parseInt(str);
        System.out.println(n);

        n = Integer.parseInt(str, 2);
        System.out.println(n);

        double x = Double.parseDouble("3.14"); 
        System.out.println(x);

        System.out.println(greeting.toUpperCase());
        System.out.println(greeting); // greeting is not changed
        
        // Unicode
        String javatm = "Java\u2122";
        System.out.println(javatm);
        System.out.println(Arrays.toString(javatm.codePoints().toArray()));
        System.out.println(javatm.length());
        
        String octonions = "\ud835\udd46";
        System.out.println(octonions);
        System.out.println(Arrays.toString(octonions.codePoints().toArray()));
        System.out.println(octonions.length()); // Counts code units, not Unicode code points
    }	
}

//______________________________________________________________________

// import java.util.Scanner;

class InputDemo {
    public static void playWithUserInput() {
        Scanner inScanner = new Scanner( System.in );

        System.out.println("What is your name?");
        String name = inScanner.nextLine();
        
        System.out.println("How old are you?");
        if ( inScanner.hasNextInt() ) {
            int age = inScanner.nextInt();
            System.out.printf("Hello, %s. Next year, you'll be %d.\n", name, age + 1);
        } else {
            System.out.printf("Hello, %s. Are you too young to enter an integer?", name);
        }
    }
}

//______________________________________________________________________

class DoDemo {
   public static void playWithDoWhile() {
      Random generator = new Random();      
      int target = 5;
      int count = 1;
      int next;

      do {
         next = generator.nextInt(10);
         count++;
      } while (next != target);
         
      System.out.println("After " + count + " iterations, there was a values of " + target);
   }
}

class ForDemo {
   public static void playWithForLoop() {
      Random generator = new Random();      
      int count = 20;
      int sum = 0;

      for (int i = 1; i <= count; i++) {
         int next = generator.nextInt(10);
         sum = sum + next;         
      }

      System.out.println("After " + count 
         + " iterations, the sum is " + sum);
   }
}

class WhileDemo {
   public static void playWithWhileLoop() {
      Random generator = new Random();
      int sum = 0;
      int count = 0;
      int target = 90;
      while (sum < target) {
         int next = generator.nextInt(10);
         sum = sum + next;
         count++;
      }
      System.out.println("After " + count 
         + " iterations, the sum is " + sum);
   }
}

//______________________________________________________________________

// import java.util.Arrays;

class ArrayDemo {

	public static void playWithArrays() {
		String[] names = new String[10];

		for ( int i = 0; i < names.length/ 2 ; i++ ) {
			names[i] = "";
		}

		System.out.println("Names:: " + Arrays.toString(names) );
		names[0] = "Gabbar Singh";
		names[1] = names[0];
		System.out.println("Names:: " + Arrays.toString(names) );


		String[] namesAgain = names;
		System.out.println("Names Again:: " + Arrays.toString(namesAgain) );

		names[0] = "Sambha";
		System.out.println("Names:: " + Arrays.toString(names) );
		System.out.println("Names Again:: " + Arrays.toString(namesAgain) );
	}
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

class JavaBasics {
	public static void main( String[] args ) {
		System.out.println("\nFunction: playWithHelloWorld");
		HelloWorld.playWithHelloWorld();
		// error: non-static method sayHello() cannot be 
		// referenced from a static context
		// HelloWorld.sayHello();
		// Created Instance/Object of Class HelloWorld
		HelloWorld hello = new HelloWorld();
		hello.sayHello();

		System.out.println("\nFunction: playWithInstanceMethods");
		MethodDemo.playWithInstanceMethods();

		System.out.println("\nFunction: playWithNumbers");
		NumberDemo.playWithNumbers();
		
		System.out.println("\nFunction: playWithSum");
		NumberDemo.playWithSum();

		System.out.println("\nFunction: playWithVariables");
		VariableDemo.playWithVariables();

		System.out.println("\nFunction: playWithOperators");
		ArithmeticDemo.playWithOperators();

		System.out.println("\nFunction: playWithBigNumbers");
		BigNumberDemo.playWithBigNumbers();

		System.out.println("\nFunction: playWithRelationalOperators");
		RelationalDemo.playWithRelationalOperators();

		System.out.println("\nFunction: playWithString");
		StringDemo.playWithString();

		System.out.println("\nFunction: playWithUserInput");
		InputDemo.playWithUserInput();

		System.out.println("\nFunction: playWithArrays");
		ArrayDemo.playWithArrays();

		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}
}

/*
https://codebunk.com/b/1871100638643/
https://codebunk.com/b/1871100638643/
https://codebunk.com/b/1871100638643/
*/
