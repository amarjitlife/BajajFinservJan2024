/*
Compiling Java Source Code
	javac JavaGenerics.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
	java -cp ClassFiles JavaGenerics
*/

// import java.util.Random;
// import java.math.BigDecimal;
// import java.math.BigInteger;
// import java.time.ZoneId;
// import java.util.Arrays;
// import java.util.Scanner;
import java.util.Arrays;
// import java.util.ArrayList;
// import java.util.Collections;
// import java.util.List;

//______________________________________________________________________

class ISEntry {
    private Integer key;
    private String value;

    public ISEntry(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey()   { return key; }    
    public String getValue() { return value; }
}

class SIEntry {
    private String key;
    private Integer value;

    public SIEntry(String key, Integer value) {
        this.key = key;
        this.value = value;
    }

    public String getKey()   { return key; }    
    public Integer getValue() { return value; }
}

//______________________________________________________________________
//
//  Generic Class/Type
//      Paramatrized Types
//______________________________________________________________________

// Generics Is A Code Which Generate Code
//      Compiler Will Replace K and V With Types
//          Replacement Type Will Be Detected At Compile Time
//          Replacement Is Done At Compile Time And Generate Code After Substitution

// Polymorphic Code
//      Polymorphism At Compile Time

// Here K and V Are Type Place Holder
class Entry<K, V> {
    private K key;
    private V value;

    public Entry(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey()   { return key; }    
    public V getValue() { return value; }
}

// Compiler Will Generate Following Code
// Compiler Generate Code By Substituing K and V
//      K Type Place Holder To Be Substituted With Integer Type
//      V Type Place Holder To Be Substituted With String  Type
class EntryIntegerString {
    private Integer key;
    private String value;

    public EntryIntegerString(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey()   { return key; }    
    public String getValue() { return value; }
}

// Compiler Will Generate Following Code
// Compiler Generate Code By Substituing K and V
//      K Type Place Holder To Be Substituted With Integer Type
//      V Type Place Holder To Be Substituted With Integer  Type
class EntryIntegerInteger {
    private Integer key;
    private Integer value;

    public EntryIntegerInteger(Integer key, Integer value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey()   { return key; }    
    public Integer getValue() { return value; }
}

class EntryDemo {
    public static void playWithEntry() {
        // Compiler Detects 
        //      K Type Place Holder To Be Substituted With Integer Type
        //      V Type Place Holder To Be Substituted With String  Type
        Entry<Integer, String> entry1 = new Entry<Integer, String>( 999, "Helloooooo!!!!");
        System.out.println( entry1.getKey() );
        System.out.println( entry1.getValue() );

        // Entry<int, int> entry1 = new Entry<int, int>();

        // Compiler Detects 
        //      K Type Place Holder To Be Substituted With Integer Type
        //      V Type Place Holder To Be Substituted With Integer  Type
        Entry<Integer, Integer> entry2 = new Entry<Integer, Integer>( 999, 888 );
        System.out.println( entry2.getKey() );
        System.out.println( entry2.getValue() );

        Entry<String, Integer> gabbar = new Entry<String, Integer>( "Gabbar Singh", 500000 );
        System.out.println( gabbar.getKey() );
        System.out.println( gabbar.getValue() );

        Entry<String, String> gabbarAgain = new Entry<String, String>( "Gabbar Singh", "Decoit" );
        System.out.println( gabbarAgain.getKey() );
        System.out.println( gabbarAgain.getValue() );
    }
}

//______________________________________________________________________

class ArrayUtil {
    public static <T> void swap( T[] array, int i, int j ) {
        T temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

// Compiler Will Generate Following Code Based On Usage By Programmer
//      Hence T Type PlaceHolder Will Be Substituted With String
class ArrayUtilGenerated {

    public static void swapString( String[] array, int i, int j ) {
        String temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public static void swapInteger( Integer[] array, int i, int j ) {
        Integer temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

class ArrayUtilDemo {
    public static void playWithArrays() {
        String[] friends = {"Gabbar Singh", "Sambha", "Kalia", "Multan Singh", "Ajam Khan" };

        System.out.println( Arrays.toString(friends) );
        // Compiler Will Infer Type From friends Argument To Function swap
        //      Inferred Type Is String[] 
        //      Hence T Type PlaceHolder Will Be Substituted With String
        ArrayUtil.swap( friends, 0, 1);

        // ArrayUtil.<String>swap( friends, 0, 1);
        System.out.println( Arrays.toString(friends) );


        Integer[] numbers = { 88, 99, 30, 50, 10, 100, 999 } ;
        System.out.println( Arrays.toString( numbers ) );
        // Compiler Will Infer Type From friends Argument To Function swap
        //      Inferred Type Is Integer[] 
        //      Hence T Type PlaceHolder Will Be Substituted With Integer
        ArrayUtil.swap( numbers, 0, 1);
        System.out.println( Arrays.toString( numbers ) );
    }
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

public class JavaGenerics {
	public static void main( String[] args ) {
        System.out.println("\nFunction: EntryDemo.playWithEntry");
        EntryDemo.playWithEntry();

        System.out.println("\nFunction: ArrayUtilDemo.playWithArrays");
        ArrayUtilDemo.playWithArrays();

        // System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}  
}

//______________________________________________________________________
//______________________________________________________________________

/*
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
*/

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
