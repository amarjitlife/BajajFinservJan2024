/*
javac JavaExceptions.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaExceptions
*/
package learnJava;

import java.util.Arrays;
import java.util.ArrayList;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.RejectedExecutionException;


//_____________________________________________________

class ThrowDemo {
    public static int randInt(int low, int high) {
        if (low > high)
            throw new IllegalArgumentException(
                "low should be <= high but low is "
                + low + " and high is " + high);

        return low + (int)(Math.random() * (high - low + 1));
    }
    
    public static void playWithExceptions() {
        System.out.println("Generating a random number...");
        int r = randInt(10, 20);
        System.out.println("r = " + r);
        System.out.println("And another...");
        
        // r = randInt(10, 5);
        // System.out.println("r = " + r);
    }
}


//_____________________________________________________

// Creating Your Own Exception Class
class FileFormatException extends IOException {
    public FileFormatException() {}
    public FileFormatException(String message) {
        super(message);
    }
}

//_____________________________________________________

class TryWithResourcesDemo {
    public static void print(Scanner in, PrintWriter out) {
        try (in; out) { // Effectively final variables
            while (in.hasNext())
                out.println(in.next().toLowerCase());            
        }
    }
    
    // Checked Exception Style Function
    public static void playWithExceptions() throws IOException {
        List<String> lines = List.of("Mary had a little lamb. Its fleece was white as snow.".split(" "));

        try (PrintWriter out = new PrintWriter("/tmp/output1.txt")) {
            for (String line : lines) {
                out.println(line.toLowerCase());
            }
        }

        try (Scanner in = new Scanner(Paths.get("/usr/share/dict/words"));
                PrintWriter out = new PrintWriter("/tmp/output2.txt")) {
            while (in.hasNext())
                out.println(in.next().toLowerCase());
        }
        
        PrintWriter out3 = new PrintWriter("/tmp/output3.txt");

        try (out3) {
            for (String line : lines) {
                out3.println(line.toLowerCase());
            }
        }                
    }
}

//_____________________________________________________

// import java.util.concurrent.RejectedExecutionException;

class FinallyNotCompletingNormallyDemo {
    public static int parseInt(String number) {
        try {
            int n = Integer.parseInt(number);
            return n;
        } catch (NumberFormatException ex) {
            return 0;            
        } finally {
            return -1; // This value is actually returned
        }
    }
    
    public static double parseDouble(String number) {
        try {
            double x = Double.parseDouble(number);
        } finally {
            throw new IllegalStateException(); // Masks NumberFormatException
        }
    }

    
    public static void playWithTryCatchFinally() {
        System.out.println(parseInt("Fred"));
        System.out.println(parseInt("123"));
        try {
            System.out.println(parseDouble("Fred"));            
        } catch(Exception ex) {
            System.out.println("Caught " + ex.getClass().getName());
        }

        try {
            System.out.println(parseDouble("12.3"));            
        } catch(Exception ex) {
            System.out.println("Caught " + ex.getClass().getName());
        }
    }
}

//_____________________________________________________


// import java.util.Arrays;
// import java.util.Scanner;

class AssertionDemo {
    public static double[] solveQuadraticEquation(double a, double b, double c) {
        double discriminant = b * b - 4 * a * c;

        assert discriminant >= 0;

        assert a != 0 : "a == 0; not a quadradic equation";
        double discrRoot = Math.sqrt(discriminant);
        return new double[] { 
                (-b - discrRoot) / (2 * a),
                (-b + discrRoot) / (2 * a)
        };
    }
    
    public static void main(String[] args) {
        try (Scanner in = new Scanner(System.in)) {
            System.out.println("Enter a b c (e.g. 0 2 1)");
            double a = in.nextDouble();
            double b = in.nextDouble();
            double c = in.nextDouble();
            System.out.println(Arrays.toString(solveQuadraticEquation(a, b, c)));
        }
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaExceptions {
    public static void main( String[] args ) {
        System.out.println("\nFunction : ThrowDemo.playWithExceptions");
        ThrowDemo.playWithExceptions();

        System.out.println("\nFunction : TryWithResourcesDemo.playWithExceptions");
        try {
            // error: unreported exception IOException; 
            //      must be caught or declared to be thrown
            TryWithResourcesDemo.playWithExceptions();
        } catch ( IOException ex ) {
            // Write Logic To Handle Exception
            System.out.println("IOException Found...");
        }

        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

