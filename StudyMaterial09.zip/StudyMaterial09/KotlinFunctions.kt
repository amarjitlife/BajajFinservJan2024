package learnKotlin

/*
// Compiling Kotlin Code
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

// Running Jar(Java Archive) File
java -jar functions.jar
*/

//______________________________________________________________________

import java.util.Random
import java.util.TreeMap

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!
// import java.util.Random

class Rectangle1( val height: Int, val width: Int ) {
	// Property With Custom Accessor Method
	val isSquare : Boolean
		//Defining Custom Getter
		get() = height == width
}

fun playWithRectangle1() {
	// Accesing Java Classes Inside Kotlin
	//		Java 1.6 Onwards Is Compatible With Kotlin
	val random = Random()
	val rectangle3 = Rectangle1( random.nextInt(), random.nextInt() )
	println( rectangle3.width )
	println( rectangle3.height )
	println( rectangle3.isSquare )	
}

//import java.util.TreeMap
fun iteratingOverMaps() {
    val binaryReps = TreeMap<Char, String>()

    for (character in 'A'..'F') {
        val binary = Integer.toBinaryString( character.code )
        binaryReps[ character ] = binary
    }

    for ((letter, binary) in binaryReps) {
        println("$letter = $binary")
    }
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithCollectionsInKotlin() {
	val set    = hashSetOf(1, 7, 53) 
	val list   = arrayListOf(1, 7, 53) 
	val map    = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    //println(numbers.max())
    println(numbers.maxOrNull())
}

// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String	
): String {
	val result = StringBuilder( prefix )
	// collection.withIndex()
	// 		It Will Generate List Of Tuples
	//		Where Each Tuple Is Tuple Of (Index, Element)
	//		Than Unpacking Tuple On index And element Variables
	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val list = listOf( "Gabbar Singh", "Thakur", "Basanti", "Jay", "Veeru", "Mausi")

	println( joinToString( list, "; ", "(", ")" ) )
	println( joinToString( list, " : ", " [ ", " ] " ) )
	println( joinToString( list, " #### ", " <<< ", " >>> " ) )
}

//______________________________________________________________________
//
// EXTENSION FUNCTIONS
//______________________________________________________________________

// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun lastChar( data: String ) = data.get( data.length - 1)

// Adding Extension Function On Type String
//		lastCharacter Is A Extension Function 
//			Added On Existing Type String
//			It Will Be Available Wherever String Object Used
fun String.lastCharacter() = this.get( this.length - 1)

fun playWithLastCharacter() {
	val greeting = "Good Evening!!!"

	println( lastChar( greeting ) )
	println( lastChar( "Hello World" ) )

	// Used Like A Member Function
	println( greeting.lastCharacter() )
	println( "Hello World".lastCharacter() )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// joinToStringExtension Extension Function On Type Collection<T>
fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String	
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val list = listOf( "Gabbar Singh", "Thakur", "Basanti", "Jay", "Veeru", "Mausi")

	println( list.joinToStringExtension( "; ", "(", ")" ) )
	println( list.joinToStringExtension( " : ", " [ ", " ] " ) )
	println( list.joinToStringExtension( " #### ", " <<< ", " >>> " ) )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Polymorhic Function
//		Mechanism : Using Function With Default Arguments

// NOTE: Always Prefer Functions With Default Arguments Over Function Overloading
//		Corollary:
//			Prefer Constructors With Default Arguments
//				Rather Than Constructor Overloading

fun <T> Collection<T>.joinToStringExtensionAgain(
	separator: String = ", ",  // Default Arguments : Arguments With Default Values
	prefix: String = "",
	postfix: String	= ""
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtensionAgain() {
	val list = listOf( "Gabbar Singh", "Thakur", "Basanti", "Jay", "Veeru", "Mausi")

	println( list.joinToStringExtensionAgain( ) ) 
	println( list.joinToStringExtensionAgain( " :: " )	)
	println( list.joinToStringExtensionAgain( " :: ", " >>>>>> " )	)
	println( list.joinToStringExtensionAgain( " :: ", " >>>>>> ", " <<<<<<< " )	)
	println( list.joinToStringExtensionAgain( "; ", "(", ")" ) )
	println( list.joinToStringExtensionAgain( " : ", " [ ", " ] " ) )
	println( list.joinToStringExtensionAgain( " #### ", " <<< ", " >>> " ) )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Extension Function join On Type Collection<String>
fun Collection<String>.join(
	separator: String = ", ",  // Default Arguments : Arguments With Default Values
	prefix: String = "",
	postfix: String	= ""
) = joinToStringExtensionAgain( separator, prefix, postfix )

fun playWithJoin() {
	val list = listOf( "Gabbar Singh", "Thakur", "Basanti", "Jay", "Veeru", "Mausi")

	println( list.join( ) ) 
	println( list.join( " :: " )	)
	println( list.join( " :: ", " >>>>>> " )	)
	println( list.join( " :: ", " >>>>>> ", " <<<<<<< " )	)
	println( list.join( "; ", "(", ")" ) )
	println( list.join( " : ", " [ ", " ] " ) )
	println( list.join( " #### ", " <<< ", " >>> " ) )
}

//______________________________________________________________________
//
//	EXTENSION PROPERTIES
//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!


val String.lastCharacter : Char
	get() = get( length - 1 )

var StringBuilder.lastCharacter : Char
	get() = get( length - 1 )
	set( value : Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithExtensionProperties() {
	val greeting = "Good Morning!"
	println( greeting.lastCharacter )
	println( "Life Is Awesome With $".lastCharacter )

	val jayMaharastra = StringBuilder("Jay Maharastra")
	println( jayMaharastra.lastCharacter )
	println( "Chatarpati Shivaji Maharaj Ki Jay Ho".lastCharacter )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun parsePath( path: String ) {
	val directory 	= path.substringBeforeLast( "/" )
	val fullName 	= path.substringAfterLast( "/" )

	val fileName 	= fullName.substringBeforeLast(".")
	val extension 	= fullName.substringAfterLast(".")

	println("Diectory: $directory, Name: $fileName, Extension: $extension")
}

fun multipleLinesTripleQuotedString() {
	val paragraph = """
			All is well!
			Life is Awesome!!!
			Where is the party?
	"""







	println( paragraph )
	println( paragraph.trimMargin() )
}

fun playWithStringFunctions() {
	parsePath("/Users/intelligene/something/somethingmore/som.doc")
	multipleLinesTripleQuotedString()
}

// Kotlin String Functions
//		String Library
//		https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Design Principle
// 		Design Towards IMMutability Rather Than Mutability

class User( val id: Int, val name: String, val address: String )

fun saveUser( user: User ) {
	if (user.name.isEmpty()) {
		throw IllegalArgumentException("Can't Save User ${user.id}: Empty Name")
	}

	if (user.address.isEmpty()) {
		throw IllegalArgumentException("Can't Save User ${user.id}: Empty Address")
	}

	saveUserInDatabase( user )
}

fun saveUserInDatabase( user: User ) = println("Saving User In Database : ${user.id}")

fun playWithSaveUser() {
	val gabbar  = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Ramgarh" )

	saveUser( gabbar )
	saveUser( basanti )
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// class User( val id: Int, val name: String, val address: String )

fun saveUserWithLocalValidate( user: User ) { //Outside/Enclosing Context
	// Local Function
	//		Function Defined Inside Function
	// NOTE: Applying DRY Principle : Don't Repeat Yourself
	//		Removing Duplicate Code
	// Enclosed Context Can Access Enclosing Context
	//		i.e. Inside Context Can Access Outside Context
	// fun validate(user: User, value: String, fieldName: String) {
	fun validate( value: String, fieldName: String) { // Inside/Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("${user.id} User Invalid: Empty $fieldName")
		}
	}

	// validate( user, user.name, "Name" )
	// validate( user, user.address, "Address" )
	validate( user.name, "Name" )
	validate( user.address, "Address" )

	saveUserInDatabase( user )
}

// fun saveUserInDatabase() user: User ) = println("Saving User In Database : ${user.id}")

fun playWithSaveUserLocalValidate() {
	val gabbar  = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Ramgarh" )

	saveUserWithLocalValidate( gabbar )
	saveUserWithLocalValidate( basanti )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// class User( val id: Int, val name: String, val address: String )

fun User.validateAndSave() { // Outside/Enclosing Context
	// Local Function
	//		Function Defined Inside Function
	// Applying DRY Principle : Don't Repeat Yourself
	fun validate( value: String, fieldName: String) { //Inside/Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("${ this.id} User Invalid: Empty $fieldName")
		}
	}

	validate( this.name, "Name" )
	validate( this.address, "Address" )
	saveUserInDatabase( this )
}

// fun saveUserInDatabase() user: User ) = println("Saving User In Database : ${user.id}")

fun playWithValidateAndSaveExtention() {
	val gabbar  = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Ramgarh" )

	// saveUserWithLocalValidate( gabbar )
	// saveUserWithLocalValidate( basanti )
	gabbar.validateAndSave()
	basanti.validateAndSave()
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!
//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!


//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

fun main() {
	println("\nFunction : playWithCollectionsInKotlin")
	playWithCollectionsInKotlin()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinToStringExtensionAgain")
	playWithJoinToStringExtensionAgain()

	println("\nFunction : playWithJoin")
	playWithJoin()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithStringFunctions")
	playWithStringFunctions()

	println("\nFunction : playWithSaveUser")
	playWithSaveUser()

	println("\nFunction : playWithSaveUserLocalValidate")
	playWithSaveUserLocalValidate()

	println("\nFunction : playWithValidateAndSaveExtention")
	playWithValidateAndSaveExtention()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//______________________________________________________________________
/*
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
*/
//______________________________________________________________________
