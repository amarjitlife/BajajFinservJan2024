rm -rf ClassFiles/
rm *.jar
rm experiments

