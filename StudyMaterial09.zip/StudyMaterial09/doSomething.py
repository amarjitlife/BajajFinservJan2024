import sys
import string

files = sys.argv[ 1 : ]
words = {}
stripping = string.whitespace + string.punctuation + string.digits + "\"'"

for file in files:
	for line in open(file):
		for word in line.lower().split():
			word = word.strip( stripping )
			if len( word ) >= 2:
				words[word] = words.get( word, 0 ) + 1

for word in sorted(words):
	print( word, words[word] )
