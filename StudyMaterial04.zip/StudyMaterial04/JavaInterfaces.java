/*
Compiling Java Source Code
javac JavaInterfaces.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
java -cp ClassFiles JavaInterfaces
*/

//______________________________________________________________________

import java.util.Random;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//______________________________________________________________________

interface IntSequence {
    boolean hasNext();
    int next();
}

class DigitSequence implements IntSequence {
    private int number;

    public DigitSequence(int n) {
        number = n;
    }

    public boolean hasNext() {
        return number != 0;
    }

    public int next() {
        int result = number % 10;
        number /= 10;
        return result;
    }
    
    public int rest() {
        return number;
    }
}


class SquareSequence implements IntSequence {
    private int i;

    public boolean hasNext() {
        return true;
    }

    public int next() {
        i++;
        return i * i;
    }
}

class IntSequenceDemo {
    public static double average(IntSequence seq, int n) {
        int count = 0;
        double sum = 0;
        while (seq.hasNext() && count < n) {
            count++;
            sum += seq.next();
        }
        return count == 0 ? 0 : sum / count;
    }

    public static void playWithIntSequences() {
        SquareSequence squares = new SquareSequence();
        double avg = average(squares, 100);
        System.out.println("Average of first 100 squares: " + avg);
        
        IntSequence digits = new DigitSequence(1729);
        while (digits.hasNext()) System.out.print(digits.next() + " ");
        System.out.println();
        
        digits = new DigitSequence(1729);
        avg = average(digits, 100);
            // Will only look at the first four sequence values
        System.out.println("Average of the digits: " + avg);
    }
}

//______________________________________________________________________

interface Identified {
    default int getId() { return Math.abs(hashCode()); } 
}


interface Person {
    String getName();
    default int getId() { return 0; }
}

class Employee implements Person, Identified {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }

    public int getId() { return Identified.super.getId(); }
}

class EmployeeDemo {
    // Member Functions Of Class
    	
    public static void playWithEmployee() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);

        gabbar.raiseSalary( 50000 );
        System.out.println(gabbar.getId());
        System.out.println(gabbar.getName());
        System.out.println(gabbar.getSalary());

        Employee samba = new Employee("Samba", 5000);

        samba.raiseSalary( 0 );
        System.out.println(samba.getId());
        System.out.println(samba.getName());
        System.out.println(samba.getSalary());
    }
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

class JavaInterfaces {
	public static void main( String[] args ) {
		System.out.println("\nFunction: playWithIntSequences");
		IntSequenceDemo.playWithIntSequences();

		System.out.println("\nFunction: ");
		EmployeeDemo.playWithEmployee();
		
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}  
}

//______________________________________________________________________
//______________________________________________________________________

/*
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
*/

//______________________________________________________________________
//______________________________________________________________________
