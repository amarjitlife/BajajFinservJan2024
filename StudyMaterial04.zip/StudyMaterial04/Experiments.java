/*
Compiling Java Source Code
	javac Experiments.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
	java -cp ClassFiles Experiments
*/

//______________________________________________________________________

// DESIGN PRINCIPLES
//		Design Towards Abstract Types Rather Than Concrete Types
//		Corollary
//			Design Towards Interfaces Rather Than Concrete Classes

// Superpower Abstract Type
//		Operatons = { fly, saveWorld }
//		Range = Phi Set

// interfaces Declare
// 		What It Will Do
interface Superpower {
	void fly();
	void saveWorld();
}

// Concrete Classes Defines 
//	How To Be Done?
//	When, Where, Which Way... etc...
class Spiderman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Spiderman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!!!"); }
}

// Concrete Classes Defines 
//	How To Be Done?
//	When, Where, Which Way... etc...
class Superman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!!!"); }
}

// Concrete Classes Defines 
//	How To Be Done?
//	When, Where, Which Way... etc...
class Batman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Batman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Batman!!!"); }
}

class Wonderwoman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Wonderwoman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!!!"); }
}

class HanumanJi implements Superpower {
	public void fly() 		{ System.out.println("Fly Like HanumanJi!!!"); }
	public void saveWorld() { System.out.println("Save World Like HanumanJi!!!"); }
}

/*
class Human {
	public void fly() 		{ System.out.println("Fly Like Human!!!"); }
	public void saveWorld() { System.out.println("Save World Like Human!!!"); }
}
*/

// Using Inheritance
// class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Batman {
class HumanDesign1 extends Wonderwoman {
	public void fly() 		{ super.fly(); 			}
	public void saveWorld() { super.saveWorld(); 	}
}

// Using Composing
class HumanDesign2 {
	// private Spiderman s = new Spiderman();
	// private Superman s = new Superman();
	// private Batman s = new Batman();
	private Wonderwoman s = new Wonderwoman();
	public void fly() 		{ s.fly(); 			}
	public void saveWorld() { s.saveWorld(); 	}
}

// Polymorphic Human
//		Invariant Code: Code Which Doesn't Change With Addition Of More Powers
class HumanDesign3 {
	public Superpower power = null;
	public void fly() 		{ if ( power != null ) power.fly(); 		}
	public void saveWorld() { if ( power != null ) power.saveWorld(); 	}
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

class Experiments {
	public static void playWithHuman() {
		HumanDesign1 h1 = new HumanDesign1();
		h1.fly();
		h1.saveWorld();

		HumanDesign2 h2 = new HumanDesign2();
		h2.fly();
		h2.saveWorld();

		HumanDesign3 h3 = new HumanDesign3();
		h3.power = new Spiderman();
		h3.fly();
		h3.saveWorld();

		h3.power = new Superman();
		h3.fly();
		h3.saveWorld();

		h3.power = new Batman();
		h3.fly();
		h3.saveWorld();

		h3.power = new Wonderwoman();
		h3.fly();
		h3.saveWorld();

		h3.power = new HanumanJi();
		h3.fly();
		h3.saveWorld();

		Spiderman s = new Spiderman();
		s.fly();
		s.saveWorld();
	}

	public static void main(String[] args) {
        System.out.println("\nFunction: playWithHuman");
        Experiments.playWithHuman();

        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");		
	}
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

