
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//______________________________________________________________________

void playWithData() {
	int data = 65;

	printf("\n Data: %d", data );
	printf("\n Data: %c", data );
	printf("\n Data: %x", data );

	int data1 = 0x41;

	printf("\n Data1: %d", data1 );
	printf("\n Data1: %c", data1 );
	printf("\n Data1: %x", data1 );
}

//______________________________________________________________________

// ATTEMPT 01
// 	Write A Arithmatic Summation Function In C/C++
//  	With The Following Signature

// DESIGN 01

int sum1( int x, int y ) {
	return x + y;
}

//______________________________________________________________________

/*

// ATTEMPT 02
// 	Write A Arithmatic Summation Function In C/C++
//  	With The Following Signature
//			It Returns Valid Aritmatic Sum
//				Or
//			Print Can't Calculate Sum For Given Values

// DESIGN 02
int sum2( int x, int y ) {
	long z = x + y;

	return z;
}

// DESIGN 03
int sum2( int x, int y ) {
	int z = x + y;

	if z > INT_MAX || z < INT_MIN {
		'Cant Calculate 
	} else {
		return x + y;
	}
}

// DESIGN 04
int sum2( int x, int y ) {
	long z = x + y;

	if z > INT_MAX || z < INT_MIN {
		'Cant Calculate 
	} else {
		return x + y;
	}
}

*/

//______________________________________________________________________

void playWithSum() {
	int a = 2147483647;
	int b = 10;

	int result = 0;

	result = sum1( a, b );
	printf("\n Result : %d", result );

	a = -2147483648;
	b = -10;
	result = sum1( a, b );
	printf("\n Result : %d", result );
}

 // Result : -2147483639
 // Result : 2147483638

//______________________________________________________________________

int sum(int a, int b) {
	int result = 0;

	if ( ( ( b > 0 ) &&  a > (INT_MAX - b )) ||
		 ( ( b < 0 ) &&  a < (INT_MIN - b ))) {
		printf("\nCan't Calculate Sum For Given Values");
		return 0;
		// exit( 1 );
	} else {
		return a + b;
	}
}

void playWithSumAgain() {
	int a = 2147483647;
	int b = 10;

	int result = 0;

	result = sum( a, b );
	printf("\n Result : %d", result );

	a = -2147483648;
	b = -10;
	result = sum( a, b );
	printf("\n Result : %d", result );
}

//______________________________________________________________________

void playWithChar() {
	// char ch = 0;
	unsigned char ch = 0;
	
	for( char i = ch ; i < 255 ; i++ ) {
		printf("\n %d :: %c ", i, i);
	}
}

//______________________________________________________________________

int summation( int x, int y )  { return x + y; }
int subtration( int x, int y ) { return x - y; }
int multiplication( int x, int y )  { return x * y; }

// calculator Is Polymorphic Function
int calculator( int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 40;
	int b = 20;
	int result = 0;

	//						   Configuring As summation
	result = calculator( a, b, summation );
	printf("\n Result : %d", result );

	//						   Configuring As substration
	result = calculator( a, b, subtration );
	printf("\n Result : %d", result );	

	result = calculator( a, b, multiplication );
	printf("\n Result : %d", result );	
}


//______________________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() {
	printf("\n Balleeee Balleeee.... Oye Hoye!!!");
}

void doHipHop() {
	printf("\n Doing Hip Hop!!! Hoo Hoooo!!!");
}

void playWithHuman() {
	// Human gabbar = { 420, "Gabbar Singh" };
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\n Human ID 	: %d", gabbar.id );
	printf("\n Human Name	: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };
	printf("\n Human ID 	: %d", basanti.id );
	printf("\n Human Name	: %s", basanti.name );
	basanti.dance();
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

int main() {
	printf("\n\nFunction : playWithData");
	playWithData();

	printf("\n\nFunction : playWithSum");
	playWithSum();

	printf("\n\nFunction : playWithSumAgain");
	playWithSumAgain();

	// printf("\n\nFunction : playWithChar");
	// playWithChar();

	printf("\n\nFunction : playWithCalculator");
	playWithCalculator();

	printf("\n\nFunction : playWithHuman");
	playWithHuman();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}

