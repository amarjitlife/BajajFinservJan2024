package learnKotlin

/*
// Compiling Kotlin Code
kotlinc KotlinClasses.kt -include-runtime -d classes.jar

// Running Jar(Java Archive) File
java -jar classes.jar
*/

//______________________________________________________________________
//
//	DESIGN CHOICES
//______________________________________________________________________

/*
// Kotlin/Modern Language Design Choices and Evolution
	1. Expressiness
	2. Strictly Typed Language
	3. Type Safety
	4. Functional Nature ( Functional Paradigm )
	5. Best Practices Are Becoming Part Of Modern Language
*/

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

// BEST PRACTICE
//		Classes Which Are Not Meant To Be Inherited Must Be Final
//		Members Functions Which Are Not Be Inherited/Redefined Must Be Final
//		In Kotlin This Best Practice Became Default Behaviour

// Coding Experiment
//		Write Following Code In Java Language

//In Kotlin : By Default 
//		Classes Are Final
//			Final Classes Are Not Inheritable
//		As Well As Members Are Also Final
//			It's Can't Redefine
//In Java
//		By Default Classes Are Open
//			Open Classes Are Inheritable

// View Is Parent Class
// error: this type is final, so it cannot be inherited from
open class View {
	// error: 'click' in 'View' is final and cannot be overridde
	// fun click() = println("View Clicked!")
	open fun click() = println("View Clicked!")
}

// Button Is Inherited From View Class
// Button Is Child Class
class Button : View() {
	// error: 'click' hides member of supertype 'View' and needs 'override' modifier
	// fun click() = println("Button Clicked!")	
	override fun click() = println("Button Clicked!")
	fun magic()	= println("Button Magic...")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	// button Object Have Two Types
	//		Button Type As Well As View Type
	val button: Button = Button()
	button.click()
	button.magic()

	var viewAgain: View = Button()
	// Sending click Message To viewAgain Object
	//		viewAgain Reference Points To Object Of Type Button
	//		Lookup Will Happen In Button Type Message-Method Mapping Table
	//		It Will Find magic() Method In Button Type Corresponding To magic Message
	//		It Will Invoke magic() Method From Button Type
	viewAgain.click()
	// error: unresolved reference: magic
	// Why Different Treatment Happening With magic Message???
	// viewAgain.magic()
	//					TypeCasting viewAgain To Button Type
	val viewAgain1: Button = viewAgain as Button
	viewAgain1.magic()
}

// Types Give Perceptive To System/Object

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

open class Parent {
	open fun doEngineering() = println("Parent Doing Engineering!!!")
}

class Child : Parent() {
	override fun doEngineering() = println("Child Doing Engineering!!!")
	fun playCricket() 			 = println("Child Playing Cricket!!") 
}

fun playWithParentAndChild() {
	val parent: Parent = Parent()
	parent.doEngineering()

	val child: Child = Child()
	child.doEngineering()
	child.playCricket()

	// kiddu Is Seen In Perceptive Of Parent
	val kiddu: Parent = Child()
	kiddu.doEngineering()
	// error: unresolved reference: playCricket
	// kiddu.playCricket()

	val originalKidduBack: Child = kiddu as Child
	originalKidduBack.doEngineering()
	originalKidduBack.playCricket()
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

open class View1 {
	open fun click() = println("View1 Clicked!!!")
}

class Button1: View1() {
	override fun click() = println("Button1 Clicked!!!")
	fun magic() = println("Button1 Magic...")
}

fun View1.showOff() 	= println("View1 ShowOff...")
fun Button1.showOff() 	= println("Button1 ShowOff...")

fun playWithExtensionFunctions() {
	val view = View1()
	view.click()
	view.showOff()

	// button Object Have Two Types
	//		Button1 Type As Well As View1 Type
	val button: Button1 = Button1()
	button.click()
	button.showOff()
	button.magic()

	// Extension Functions Doesn't Participate In Overriding
	var viewAgain: View1 = Button1()
	viewAgain.click()
	viewAgain.showOff()
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

// Abstract Type
// What To Do?
interface Clickable2 {
	// Abstract Methods
	fun click()
	fun magic()
}

// Concrete Class/Type
// Which, When, Why, How, Where...
class Button2: Clickable2 {
	override fun click() = println("Button2 Clicked!!")
	override fun magic() = println("Button2 Magic...")
}

fun playWithInterfaces() {
	val button = Button2()
	button.click()
	button.magic()
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

interface Clickable3 {
	// Abstract Methods
	fun click()
	fun showOff() = println("Clickable3 ShowOff...")
}

interface Focusable3 {
	fun setFocus( status: Boolean ) {
		println("Life ${ if(status) "Awesome!" else "Hell" }" )
	}

	fun showOff() = println("Focusable3 ShowOff...")
}

// Concrete Class/Type
// Which, When, Why, How, Where...
class Button3: Clickable3, Focusable3 {
	override fun click() = println("Button3 Clicked!!")

	override fun showOff() {
		//error: many supertypes available, please specify the 
		// one you mean in angle brackets, e.g. 'super<Foo>'
		// super.showOff()
		super<Focusable3>.showOff()
		super<Clickable3>.showOff()
	}
}

fun playWithMutipleInterfaces() {
	val button = Button3()
	button.click()
	button.setFocus( true )
	button.showOff()
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

// DESIGN PRINCIPLE
//		Exceptions Are Not That Exceptionals Such That It Breaks Your Design

// DESIGN PRACTICES
//		1. Always Try To Eliminate else Branch
//		2. Always Try To Get Ride Of Throwing Exceptions
enum class Colour {
	RED, GREEN, BLUE, YELLOW, ORANGE
}

fun getStringForColour( colour: Colour ) : String {
	return when( colour ) {
		Colour.RED 		-> "It's Red Colour"
		Colour.GREEN 	-> "It's Green Colour"
		Colour.BLUE 	-> "It's Blue Colour"
		Colour.YELLOW 	-> "It's Yellow Colour"
		Colour.ORANGE 	-> "It's Orange Colour"
		// warning: 'when' is exhaustive so 'else' is redundant here
		// else 			-> "Unknown Colour"
	}
}

fun playWithColours() {
	println( getStringForColour( Colour.RED ) )
	println( getStringForColour( Colour.GREEN ) )
	println( getStringForColour( Colour.ORANGE ) )
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

enum class Color {
	RED, GREEN, BLUE, YELLOW, ORANGE, UKNOWN
}

fun mixColors( color1: Color, color2: Color ) : Any {
	return when( setOf( color1, color2) ) {
		setOf( Color.BLUE, Color.GREEN ) -> Color.YELLOW
		setOf( Color.RED, Color.YELLOW ) -> Color.ORANGE
		// else -> throw Exception("Unknown Color")
		else -> "Unknown Color"
	}
}

// fun mixColors1( color1: Color, color2: Color ) : Any = when( setOf( color1, color2) ) {
fun mixColors1( color1: Color, color2: Color ) = when( setOf( color1, color2) ) {
	setOf( Color.BLUE, Color.GREEN ) -> Color.YELLOW
	setOf( Color.RED, Color.YELLOW ) -> Color.ORANGE
	// else -> throw Exception("Unknown Color")
	else -> "Unknown Color"
}

// Above Codes mixColor and mixColors1 Are Similar
// Inferred Type Will Be Any

// Following Design Is Best
fun mixColorsAgain( color1: Color, color2: Color ) : Color {
	return when( setOf( color1, color2) ) {
		setOf( Color.BLUE, Color.GREEN ) -> Color.YELLOW
		setOf( Color.RED, Color.YELLOW ) -> Color.ORANGE
		// else -> throw Exception("Unknown Color")
		// else -> "Unknown Color"
		else  -> Color.UKNOWN
	}
}

fun playWithColorMixing() {
	println( mixColors( Color.GREEN, Color.BLUE ) )
	println( mixColors( Color.YELLOW, Color.RED ) )
	println( mixColors( Color.BLUE, Color.GREEN ) )
	println( mixColors( Color.ORANGE, Color.GREEN ) )	

	println( mixColorsAgain( Color.GREEN, Color.BLUE ) )
	println( mixColorsAgain( Color.YELLOW, Color.RED ) )
	println( mixColorsAgain( Color.BLUE, Color.GREEN ) )
	println( mixColorsAgain( Color.ORANGE, Color.GREEN ) )	
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr
// class Sub( val left: Expr, val right: Expr ) : Expr

fun evaluate( e : Expr ) : Int = when( e ) {
	is Num -> e.value
	is Sum -> evaluate( e.left ) + evaluate( e.right )
	// is Sub -> evaluate( e.left ) - evaluate( e.right )
	// error: 'when' expression must be exhaustive, add necessary 'else' branch
	else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num(200)) ) )

	// (100 + 200) + 300
	println( evaluate( Sum( Sum( Num(100), Num(200)), Num(300))  ))	
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

sealed class Expr1 {
	// Classes Defined Inside A Class
	class Num( val value: Int ) : Expr1()
	class Sum( val left: Expr1, val right: Expr1 ) : Expr1()
}

fun evaluateAgain( e : Expr1 ) : Int = when( e ) {
	is Expr1.Num -> e.value
	is Expr1.Sum -> evaluateAgain( e.left ) + evaluateAgain( e.right )
	// warning: 'when' is exhaustive so 'else' is redundant here
	// else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evaluateAgain( Expr1.Sum( Expr1.Num(100), Expr1.Num(200)) ) )

	// (100 + 200) + 300
	println( evaluateAgain( Expr1.Sum( 
		Expr1.Sum( Expr1.Num(100), Expr1.Num(200)), 
		Expr1.Num(300))  ))	
}

// Sealed classes and interfaces represent restricted class hierarchies 
// that provide more control over inheritance. 

// All direct subclasses of a sealed class are known at compile time. 
// No other subclasses may appear outside a module within which 
// the sealed class is defined. 

// For example, third-party clients can't extend your sealed class 
// in their code. 

// Thus, each instance of a sealed class has a type from a limited set 
// that is known when this class is compiled.

// The same works for sealed interfaces and their implementations: 
// once a module with a sealed interface is compiled, 
// no new implementations can appear.

// In some sense, sealed classes are similar to enum classes:

// the set of values for an enum type is also restricted, 
// but each enum constant exists only as a single instance, 
// whereas a subclass of a sealed class can have multiple instances, 
// each with its own state.


// sealed interface Error

// sealed class IOError(): Error

// class FileReadError(val file: File): IOError()
// class DatabaseError(val source: DataSource): IOError()

// object RuntimeError : Error

// fun log(e: Error) = when(e) {
//     is FileReadError -> { println("Error while reading file ${e.file}") }
//     is DatabaseError -> { println("Error while reading from database ${e.source}") }
//     is RuntimeError  -> { println("Runtime error") }
//     // the `else` clause is not required because all the cases are covered
// }


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

// ColorAgain Type
//		Operation = { rgb() }
//		Range = { RED, GREEN, BLUE, YELLOW, ORANGE, INDIGO, VIOLET }

enum class ColorAgain(val r: Int, val g: Int, val b: Int) {
	// Every enum Constant Have Same Constructor
	//		Having Same Properties To Be Initialised
	RED(255, 0, 0) , GREEN(0, 255, 0), BLUE(0, 0, 255), YELLOW(0, 200, 200),
	ORANGE(200, 200, 0), INDIGO(100, 100, 100), VIOLET(50, 50, 50);

	fun rgb() = (r * 256 + g) * 256 + b
}

// In Kotlin
//		when Is Type Safe Expression
//		when ( EXPRESSION ) Here EXPRESSION can be any valid Kotlin Object
fun yeDilMangeeMore( color: ColorAgain ) = when( color ) {
	ColorAgain.RED 		-> "It's Red Color"
	ColorAgain.GREEN 	-> "It's Green Color"
	ColorAgain.BLUE 		-> "It's Blue Color"
	ColorAgain.YELLOW 	-> "It's Yellow Color"
	ColorAgain.ORANGE 	-> "It's Orange Color"
	ColorAgain.INDIGO 	-> "It's Indigo Color"
	ColorAgain.VIOLET 	-> "It's Violet Color"
}

fun playWithColors() {
	println( ColorAgain.RED )
	println( ColorAgain.GREEN )
	println( ColorAgain.BLUE )

	println( ColorAgain.RED.r )
	println( ColorAgain.RED.g )
	println( ColorAgain.RED.b )
	println( ColorAgain.GREEN.r )
	println( ColorAgain.GREEN.g )
	println( ColorAgain.GREEN.b )

	println( yeDilMangeeMore( ColorAgain.RED ) )
	println( yeDilMangeeMore( ColorAgain.GREEN ) )
	println( yeDilMangeeMore( ColorAgain.BLUE ) )

	println( ColorAgain.RED.rgb() )
	println( ColorAgain.GREEN.rgb() )
	println( ColorAgain.BLUE.rgb() )
}

fun getWarmth(color: ColorAgain) = when(color) {
    ColorAgain.RED, ColorAgain.ORANGE, ColorAgain.YELLOW -> "warm"
    ColorAgain.GREEN -> "neutral"
    ColorAgain.BLUE, ColorAgain.INDIGO, ColorAgain.VIOLET -> "cold"
}

// when ( EXPRESSION ) Here EXPRESSION can be any valid Kotlin Object
fun mixColors(c1: ColorAgain, c2: ColorAgain) = when ( setOf(c1, c2) ) {
    setOf(ColorAgain.RED, ColorAgain.YELLOW)  -> ColorAgain.ORANGE
    setOf(ColorAgain.YELLOW, ColorAgain.BLUE) -> ColorAgain.GREEN
    setOf(ColorAgain.BLUE, ColorAgain.VIOLET) -> ColorAgain.INDIGO
    else -> throw Exception("Dirty Color")
}

fun mixColorsOptimized(c1: ColorAgain, c2: ColorAgain) = when {
    (c1 == ColorAgain.RED && c2 == ColorAgain.YELLOW)  || 
    (c1 == ColorAgain.YELLOW && c2 == ColorAgain.RED) 	-> ColorAgain.ORANGE
    (c1 == ColorAgain.YELLOW && c2 == ColorAgain.BLUE) || 
    (c1 == ColorAgain.BLUE && c2 == ColorAgain.YELLOW) 	-> ColorAgain.GREEN
    (c1 == ColorAgain.BLUE && c2 == ColorAgain.VIOLET) || 
    (c1 == ColorAgain.VIOLET && c2 == ColorAgain.BLUE) 	-> ColorAgain.INDIGO
    else -> throw Exception("Dirty Color")
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

//							Constructor With Default Argument Values
class User( val nickName: String, val isSubscribed: Boolean = false )

fun playWithUser() {
	val gabbar = User( "Gabbar" )
	println( gabbar.nickName )
	println( gabbar.isSubscribed )

	val gabbarAgain = User( "Gabbar Singh", true )
	println( gabbarAgain.nickName )
	println( gabbarAgain.isSubscribed )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

// Creating Interface Having Property 

interface UserInterface {
	val nickname: String
}

fun getFacebookName( accountID: Int ) = "FB:$accountID"

// error: 'nickname' hides member of supertype 'UserInterface' and needs 'override' modifier
// class PrivateUser( val nickname: String ) : UserInterface
class PrivateUser( override val nickname: String ) : UserInterface

class SubscribingUser( val email: String ) : UserInterface {
	// error: 'nickname' hides member of supertype 'UserInterface' and needs 'override' modifier
	// val nickname: String
	override val nickname: String	
		get() = email.substringBefore( '@' )
}

class FacebookUser( val accountID: Int ) : UserInterface {
	override val nickname = getFacebookName( accountID )
}

fun playWithInterfaceProperties() {
	val gabbar = PrivateUser("gabbar@ramgarh.com")
	println( gabbar.nickname )

	val basanti = SubscribingUser( "basanti@ramgarh.com" )
	println( basanti.nickname )

	val thakur = FacebookUser( 999 )
	println( thakur.nickname )
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!
//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!
//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithParentAndChild")
	playWithParentAndChild()

	println("\nFunction : playWithExtensionFunctions")
	playWithExtensionFunctions()

	println("\nFunction : playWithInterfaces")
	playWithInterfaces()

	println("\nFunction : playWithMutipleInterfaces")
	playWithMutipleInterfaces()

	println("\nFunction : playWithColours")
	playWithColours()

	println("\nFunction : playWithColorMixing")
	playWithColorMixing()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithUser")
	playWithUser()

	println("\nFunction : playWithInterfaceProperties")
	playWithInterfaceProperties()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//______________________________________________________________________
//______________________________________________________________________
