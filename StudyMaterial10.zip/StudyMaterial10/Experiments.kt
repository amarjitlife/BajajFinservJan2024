/***
kotlinc Experiments.kt -include-runtime -d experiments.jar
java -jar experiments.jar 
***/
package learnKotlin

//_____________________________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( x: Int, y: Int ) : Int = x + y
fun sub( x: Int, y: Int ) : Int = x - y
fun mul( x: Int, y: Int ) : Int = x * y

// Polymorphic Function
//		Using Mechanism 
//			By Passing Function To Function
//			OR Passing A Behviour To Behaviour
// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(x, y)
}

fun playWithCalculator() {
	val a: Int = 200;
	val b: Int = 100;
	var result: Int;

	result = calculator( a, b, ::sum )
	println("Result : $result")

										// Lambda Expression
	val sumLambda: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator( a, b, sumLambda )
	println("Result : $result")

	result = calculator( a, b, ::sub )
	println("Result : $result")

										// Lambda Expression
	val subLambda: (Int, Int) -> Int = { x: Int, y: Int -> x - y }
	result = calculator( a, b, subLambda )
	println("Result : $result")


	result = calculator( a, b, ::mul )
	println("Result : $result")

	var something = ::sum
	result = something( 100, 200 )
	println("Result : $result")

	var something1: (Int, Int) -> Int = ::sum
	result = something1( 100, 200 )
	println("Result : $result")

	var somethingAgain = ::calculator
	result = somethingAgain( 100, 200, ::sum )
	println("Result : $result")

	var somethingAgain1: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingAgain1( 100, 200, ::sum )
	println("Result : $result")
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


