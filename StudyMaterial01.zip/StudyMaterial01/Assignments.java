
//______________________________________________________________________
//
// DAY 01
//______________________________________________________________________

	Assignment D01.A1 : Reading Thinking and Experimentation Assignments

		The C Programming Language, 2nd Edition
			Kernigham and Dennish Ritchie

			Chapter 2 - Types, Operators and Expressions 
			Chapter 3 - Control Flow

		Thinking and Experimentation Assignments
			In C/C++/Java/Python/JavaScript
			1. Explore Divide By Zero Behaviour 
			2. Explore Comparison Of float and double Type Data

//______________________________________________________________________
//______________________________________________________________________

