/*
Compiling Java Source Code
	javac JavaBasics.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
	java -cp ClassFiles JavaBasics
*/

import java.util.Random;

//______________________________________________________________________

class HelloWorld {
	// Class Method :: Static Context
	public static void playWithHelloWorld() {
		System.out.println("Hello World!!!");
	}

	// Instance/Object Method :: Non-Static Context
	public void sayHello() {
		System.out.println("Hello Helloooooo!!!");		
	}
}

//______________________________________________________________________
// import java.util.Random;

class MethodDemo {
	public static void playWithInstanceMethods() {
		Random generator = new Random();

		System.out.println( generator.nextInt() );
		System.out.println( generator.nextInt() );
	}
}

//______________________________________________________________________

class NumberDemo {

	public static void playWithNumbers() {
        System.out.println(4000000000L); 
        System.out.println(0xCAFEBABE); 
        System.out.println(0b1001); 
        System.out.println(011); 

        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);        

        // Default Type For Constant Literal 3.14 Is Double
        //		Following Both Lines Are Equivalent
        System.out.println(3.14); 
        System.out.println(3.14D); 

        // 3.14F Is Float Type Value
        System.out.println(3.14F); 

        // try {
	        System.out.println( 1.0 / 0.0 ); 
	        System.out.println( -1.0 / 0.0 ); 
	        System.out.println( 0.0 / 0.0 ); 
	    // } catch ( ArithmaticException ex ) { // BAD CODE
	    // 	// Hanlding Code
	    // }

// Infinity
// -Infinity
// NaN
        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);
        System.out.println(0.0 / 0.0 == Double.NaN);
// true
// true
// false

        double x = 2.0;
        double y = 1.1;

        if ( x - y == 0.9 ) {
        	System.out.println("\n Equal");
        } else {
        	System.out.println("\n UNEqual");
        }

        // System.out.println( );
        // System.out.println( ); 
        // System.out.println( ); 
        // System.out.println( ); 
        // System.out.println( ); 
        // System.out.println( ); 
        // System.out.println( ); 
        // System.out.println( ); 
        // System.out.println( ); 
	}


	public static int sum( int x, int y ) {
		return x + y;
	}

	public static void playWithSum() {
		int a = 2147483647;
		int b = 10;

		int result = 0;

		result = sum( a, b );
		System.out.println( "Result : " + result );

		a = -2147483648;
		b = -10;
		result = sum( a, b );
		System.out.println( "Result : " + result );
	}
}


//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

class JavaBasics {
	public static void main( String[] args ) {
		System.out.println("\nFunction: playWithHelloWorld");
		HelloWorld.playWithHelloWorld();
		// error: non-static method sayHello() cannot be 
		// referenced from a static context
		// HelloWorld.sayHello();
		// Created Instance/Object of Class HelloWorld
		HelloWorld hello = new HelloWorld();
		hello.sayHello();

		System.out.println("\nFunction: playWithInstanceMethods");
		MethodDemo.playWithInstanceMethods();

		System.out.println("\nFunction: playWithNumbers");
		NumberDemo.playWithNumbers();
		
		System.out.println("\nFunction: playWithSum");
		NumberDemo.playWithSum();
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}
}

/*
https://codebunk.com/b/1871100638643/
https://codebunk.com/b/1871100638643/
https://codebunk.com/b/1871100638643/
https://codebunk.com/b/1871100638643/
*/
