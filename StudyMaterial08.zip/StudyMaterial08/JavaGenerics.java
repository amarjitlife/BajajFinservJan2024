/*
Compiling Java Source Code
	javac JavaGenerics.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
	java -cp ClassFiles JavaGenerics
*/

import java.util.Arrays;
import java.util.ArrayList;
import java.io.PrintStream;

import java.util.function.Predicate;

//______________________________________________________________________

class ISEntry {
    private Integer key;
    private String value;

    public ISEntry(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey()   { return key; }    
    public String getValue() { return value; }
}

class SIEntry {
    private String key;
    private Integer value;

    public SIEntry(String key, Integer value) {
        this.key = key;
        this.value = value;
    }

    public String getKey()   { return key; }    
    public Integer getValue() { return value; }
}

//______________________________________________________________________
//
//  Generic Class/Type
//      Paramatrized Types
//______________________________________________________________________

// Generics Is A Code Which Generate Code
//      Compiler Will Replace K and V With Types
//          Replacement Type Will Be Detected At Compile Time
//          Replacement Is Done At Compile Time And Generate Code After Substitution

// Polymorphic Code
//      Polymorphism At Compile Time

// Here K and V Are Type Place Holder
class Entry<K, V> {
    private K key;
    private V value;

    public Entry(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey()   { return key; }    
    public V getValue() { return value; }
}

// Compiler Will Generate Following Code
// Compiler Generate Code By Substituing K and V
//      K Type Place Holder To Be Substituted With Integer Type
//      V Type Place Holder To Be Substituted With String  Type
class EntryIntegerString {
    private Integer key;
    private String value;

    public EntryIntegerString(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey()   { return key; }    
    public String getValue() { return value; }
}

// Compiler Will Generate Following Code
// Compiler Generate Code By Substituing K and V
//      K Type Place Holder To Be Substituted With Integer Type
//      V Type Place Holder To Be Substituted With Integer  Type
class EntryIntegerInteger {
    private Integer key;
    private Integer value;

    public EntryIntegerInteger(Integer key, Integer value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey()   { return key; }    
    public Integer getValue() { return value; }
}

class EntryDemo {
    public static void playWithEntry() {
        // Compiler Detects 
        //      K Type Place Holder To Be Substituted With Integer Type
        //      V Type Place Holder To Be Substituted With String  Type
        Entry<Integer, String> entry1 = new Entry<Integer, String>( 999, "Helloooooo!!!!");
        System.out.println( entry1.getKey() );
        System.out.println( entry1.getValue() );

        // Entry<int, int> entry1 = new Entry<int, int>();

        // Compiler Detects 
        //      K Type Place Holder To Be Substituted With Integer Type
        //      V Type Place Holder To Be Substituted With Integer  Type
        Entry<Integer, Integer> entry2 = new Entry<Integer, Integer>( 999, 888 );
        System.out.println( entry2.getKey() );
        System.out.println( entry2.getValue() );

        Entry<String, Integer> gabbar = new Entry<String, Integer>( "Gabbar Singh", 500000 );
        System.out.println( gabbar.getKey() );
        System.out.println( gabbar.getValue() );

        Entry<String, String> gabbarAgain = new Entry<String, String>( "Gabbar Singh", "Decoit" );
        System.out.println( gabbarAgain.getKey() );
        System.out.println( gabbarAgain.getValue() );
    }
}

//______________________________________________________________________
//
// Generic Function/Function Type
//      Paramerized Type
//______________________________________________________________________

class ArrayUtil {
    public static <T> void swap( T[] array, int i, int j ) {
        T temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

// Compiler Will Generate Following Code Based On Usage By Programmer
//      Hence T Type PlaceHolder Will Be Substituted With String
// class ArrayUtilGenerated {
//     public static void swapString( String[] array, int i, int j ) {
//         String temp = array[i];
//         array[i] = array[j];
//         array[j] = temp;
//     }

//     public static void swapInteger( Integer[] array, int i, int j ) {
//         Integer temp = array[i];
//         array[i] = array[j];
//         array[j] = temp;
//     }
// }

class ArrayUtilDemo {
    public static void playWithArrays() {
        String[] friends = {"Gabbar Singh", "Sambha", "Kalia", "Multan Singh", "Ajam Khan" };

        System.out.println( Arrays.toString(friends) );
        // Compiler Will Infer Type From friends Argument To Function swap
        //      Inferred Type Is String[] 
        //      Hence T Type PlaceHolder Will Be Substituted With String
        ArrayUtil.swap( friends, 0, 1);

        // ArrayUtil.<String>swap( friends, 0, 1);
        System.out.println( Arrays.toString(friends) );


        Integer[] numbers = { 88, 99, 30, 50, 10, 100, 999 } ;
        System.out.println( Arrays.toString( numbers ) );
        // Compiler Will Infer Type From friends Argument To Function swap
        //      Inferred Type Is Integer[] 
        //      Hence T Type PlaceHolder Will Be Substituted With Integer
        ArrayUtil.swap( numbers, 0, 1);
        System.out.println( Arrays.toString( numbers ) );
    }
}

//______________________________________________________________________

class ArrayUtilAgain {

    public static <T> void swap( T[] array, int i, int j ) {
        T temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

// _________________________________________________________
//
// HOW COME HEAP CORRUPTION IS HAPPING IN FOLLOWING CODE???
// _________________________________________________________

// Note: JavaGenerics.java uses unchecked or unsafe operations.
// Note: Recompile with -Xlint:unchecked for details

// JavaGenerics.java:197: warning: [unchecked] Possible heap pollution from parameterized vararg type T
//     public static <T> T[] swap( int i, int j, T... values ) {
//                                     ^
//   where T is a type-variable:
//     T extends Object declared in method <T>swap(int,int,T...)

    public static <T> T[] swap( int i, int j, T... values ) {
        T temp = values[i];
        values[i] = values[j];
        values[j] = temp;

        return values;
    }
}

class ArrayUtilAgainDemo {
    public static void playWithArrays() {
        String[] friends = {"Gabbar Singh", "Sambha", "Kalia", "Multan Singh", "Ajam Khan" };

        System.out.println( Arrays.toString(friends) );
        ArrayUtilAgain.swap( friends, 0, 1);
        System.out.println( Arrays.toString(friends) );

        System.out.println( Arrays.toString(friends) );
        ArrayUtilAgain.swap( 0, 1, friends );
        System.out.println( Arrays.toString(friends) );
    }
}

//______________________________________________________________________
//
//  Type Bounds
//______________________________________________________________________

// import java.util.ArrayList;
// import java.io.PrintStream;

class Closeables {
    // public static <T> void closeAll( ArrayList<T> elements ) throws Exception {
    public static <T extends AutoCloseable> void closeAll( ArrayList<T> elements ) throws Exception {
        // error: cannot find symbol close()
        for ( T element : elements ) element.close();
    }
}

class CloseableDemo {
    public static void playWithCloseables() {
        try {
            PrintStream stream1 = new PrintStream("/tmp/1");
            PrintStream stream2 = new PrintStream("/tmp/2");

            // Following 2 Lines Code Are Similar Things
            // ArrayList<PrintStream> streams = new ArrayList<PrintStream>();
            ArrayList<PrintStream> streams = new ArrayList<>();
            streams.add( stream1 );
            streams.add( stream2 );
            Closeables.closeAll( streams );

            ArrayList<String> names = new ArrayList<>();
            names.add("Gabbar Singh");
            names.add("Samba");
            names.add("Basanti");

// JavaGenerics.java:262: error: method closeAll in class Closeables cannot 
//                                               be applied to given types;
//             Closeables.closeAll( names );
//                       ^
//   required: ArrayList<T>
//   found:    ArrayList<String>
//   reason: inference variable T has incompatible bounds
//     equality constraints: String
//     lower bounds: AutoCloseable
//   where T is a type-variable:
//     T extends AutoCloseable declared in method <T>closeAll(ArrayList<T>)

            // Closeables.closeAll( names );

        } catch ( Exception ex ) {
            System.out.printf("Exception Found : %s", ex );
        }
    
    }
}

//______________________________________________________________________

// import java.util.function.Predicate;

class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public final String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

class Manager extends Employee {
    private double bonus;

    public Manager(String name, double salary) { 
        super(name, salary);
        bonus = 0;
    }

    public void setBonus( double bonus ) {
        this.bonus = bonus;
    }

    public double getSalary() {
        return super.getSalary() + bonus;
    }
}

class Employees {
    public static void printAll1( Employee[] staff, Predicate<Employee> filter ) {
        for (Employee employee : staff ) {
            if ( filter.test( employee ) ) {
                System.out.println( employee.getName() + " :: " + employee.getSalary() );
            } else {
                // System.out.println( employee.getName() + " :: " + employee.getSalary() );
            }
        }
    }

// JavaGenerics.java:346: error: incompatible types: Employee cannot be converted to CAP#1
// public static void printAll2( Employee[] staff, Predicate<> filter ) {
    public static void printAll2( Employee[] staff, Predicate<? super Employee> filter ) {
        for (Employee employee : staff ) {
            if ( filter.test( employee ) ) {
                System.out.println( employee.getName() + " :: " + employee.getSalary() );
            } else {
                // System.out.println( employee.getName() + " :: " + employee.getSalary() );
            }
        }
    }

    public static void playWithStaff() {
        Employee[] employees = {
            new Manager("Gabbar Singh", 500000),
            new Employee("Sambha", 5000),
            new Employee("Kalia",  1000),
            new Manager("Thakur", 1000000000),
            new Employee("Veeru", 5000),
            new Employee("Jay",  1000),    
            new Employee("Basanti", 5000),
            new Employee("Raadha",  1000000000),            
        };

        // STYLE 01 :CREATING CONCRETE CLASS BY IMPLEMENTING INTERFACES
        class MoreThan5000 implements Predicate<Employee> {
            public boolean test(Employee employee) {
                return employee.getSalary() >= 5000;
            }
        }

        System.out.println("Employees Having Salary More Than 5000");
        printAll1( employees, new MoreThan5000() );

        class LessThan5000 implements Predicate<Employee> {
            public boolean test(Employee employee) {
                return employee.getSalary() < 5000;
            }
        }

        System.out.println("Employees Having Salary Less Than 5000");
        printAll1( employees, new LessThan5000() );

        // STYLE 02: USING ANONYMOUS CLASSES
        System.out.println("Employees Having Salary More Than 5000");
        printAll1( employees, new Predicate<Employee>() {
                                    public boolean test(Employee employee) {
                                        return employee.getSalary() >= 5000;
                                    }
                             } 
                );

        System.out.println("Employees Having Salary Less Than 5000");
        printAll1( employees, new Predicate<Employee>() {
                                    public boolean test(Employee employee) {
                                        return employee.getSalary() < 5000;
                                    }
                             } 
                );

        // STYLE 03: USING LAMBDA EXPRESSIONS
        System.out.println("Employees Having Salary More Than 5000");
        printAll1( employees, employee -> employee.getSalary() >= 5000 );

        System.out.println("Employees Having Salary Less Than 5000");
        printAll1( employees, employee -> employee.getSalary() < 5000 );

        System.out.println("Employees Having Salary More Than 5000");
        printAll2( employees, employee -> employee.getSalary() >= 5000 );

        System.out.println("Employees Having Salary Less Than 5000");
        printAll2( employees, employee -> employee.getSalary() < 5000 );
    }
}

//______________________________________________________________________

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

public class JavaGenerics {
	public static void main( String[] args ) {
        System.out.println("\nFunction: EntryDemo.playWithEntry");
        EntryDemo.playWithEntry();

        System.out.println("\nFunction: ArrayUtilDemo.playWithArrays");
        ArrayUtilDemo.playWithArrays();

        System.out.println("\nFunction: ArrayUtilAgainDemo.playWithArrays");
        ArrayUtilAgainDemo.playWithArrays();

		System.out.println("\nFunction: CloseableDemo.playWithCloseables");
        CloseableDemo.playWithCloseables();

		System.out.println("\nFunction: Employees.playWithStaff()");
        Employees.playWithStaff();
		
        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}  
}

//______________________________________________________________________
//______________________________________________________________________

/*
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
*/

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
