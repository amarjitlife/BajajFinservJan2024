package learnKotlin


/*
// Compiling Kotlin Code
kotlinc KotlinBasics.kt -include-runtime -d basics.jar

// Running Jar(Java Archive) File
java -jar basics.jar
*/

//______________________________________________________________________

import java.util.Random
import java.util.TreeMap

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// ??? THINKING QUESTION ???
// 		Which Design Is Better Return Type Unit Or void 

// In Kotlin
// 		Default Return Type Of Function Is Unit
// In Java
// 		Default Return Type Of Function Is void

// Following Function Doesn't Take Any Arguments 
//		And Returns Unit Value Of Unit Type
// fun helloWorld() : Unit {
fun helloWorld() {	
	println("Hello World! Welcome To Kotlin!!!!")
}

// error: type mismatch: inferred type is String but Unit was expected
// fun helloWorldAgain(){	
fun helloWorldAgain() : String {	
	return "Hello World! Welcome To Kotlin!!!!"
}

fun playWithHelloWorld() {
	helloWorld()
	println( helloWorldAgain() )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// fun max(a: Int, b: Int)  {
fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b
}

// Compiler Will Do Following
//	1. Compiler Will Infer Type From RHS Value
//	2. Bind The Inferred Type To LHS Identifier
fun maximum(a: Int, b: Int) = if ( a > b ) a else b  //"Ding Dong"

fun playWithMaximum() {
	// Immutable State
	val aa = 900
	val bb = 1000
	// Mutable State
	var result: Int

	result = max( aa, bb )
	println("Result : $result"); // Semicolon Is Optional

	// Function Call With Labels
	result = max( a = aa, b = bb )
	println("Result : $result"); // Semicolon Is Optional

	result = max( b = bb, a = aa  )
	println("Result : $result"); // Semicolon Is Optional

	result = maximum( aa, bb )
	println("Result : $result"); // Semicolon Is Optional
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Kotlin Compiler Will Generate Following Things
//		1. Constructor i.e. Meberwise Initialser
//				It Will Initialise All The Members
//		2. It Will Create Two Member Variables
//				For name And isMarried Properties
//		3. It Will Generate Getters and Setters For Each Property
//				For val Propery Only Getter Generated
//				For var Proeprty Both Getter and Setter Generated
//				Getter and Setters Name Will Same As Property Name

class Person( val name: String, var isMarried: Boolean )

fun playWithPerson() {
	// Daku : Decoit
	val gabbar = Person("Gabbar Singh", false )
	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

 	// error: val cannot be reassigned
	// gabbar.name = "Gabbar Decoit"
	gabbar.isMarried = true 	// gabbar.setIsMarried( true )

	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	val basanti = Person("Basanti", true )
	println( basanti.name ) 	// basanti.getName()
	println( basanti.isMarried )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithTypeInferringAndBinding() {
	// Compiler Will Do Following
	//	1. Compiler Will Infer Type From RHS Value
	//	2. Bind The Inferred Type To LHS Identifier

	// In Kotlin
	//		Type Inferrence and Binding Happens At Compile Time
	//		You Can't Change Type Of Object At Runtime
	// In Python/JavaScript/Ruby
	//		Type Inferrence and Binding Happens At Runtime Time
	//		You Can Change Type Of Object At Runtime

	// something Binded To Type Int
	val something = 900 // Inferred Type Is Int From RHS
	// Explicitly Annotated Type
	val something1: Int = 900

	println( something )
	println( something1 )

	val somethingAgain = 900.90 // Inferred Type Is Double From RHS
	// Explicitly Annotated Type
	val somethingAgain1: Double = 900.90
	val somethingAgain2: Float = 900.90F

	println( somethingAgain )
	println( somethingAgain1 )
	println( somethingAgain2 )

	val greeting = "Good Afternoon!" // Inferred Type Is String From RHS
	val greeting1: String = "Good Afternoon!"
	
	println( greeting )
	println( greeting1 )

	// gabbar Is Of Person Type
	val gabbar = Person("Gabbar Singh", false ) // Inferred Type Is Person From RHS
	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Kotlin Compiler Will Generate Following Things
//		1. Constructor i.e. Meberwise Initialser
//				Rectangle( height: Int, width: Int )
//				It Will Initialise Two The Members
//		2. It Will Create Three Member Variables
//				For All Properties
//		3. It Will Generate Getters and Setters For Each Property
//				For val Propery Only Getter Generated
//				For var Proeprty Both Getter and Setter Generated
//				For isSquare Property It Won't Generate Getter
///						Because Programmer Provided Custom Getter

				// Constructor Signature
class Rectangle( val height: Int, val width: Int ) {
	// Property With Custom Accessor Method
	val isSquare : Boolean
		get() { //Defining Custom Getter
			println("isSquare Getter Called...")
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle( 100, 200 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle( 444, 444 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )	
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// import java.util.Random

class Rectangle1( val height: Int, val width: Int ) {
	// Property With Custom Accessor Method
	val isSquare : Boolean
		//Defining Custom Getter
		get() = height == width
}

fun playWithRectangle1() {
	val rectangle1 = Rectangle1( 100, 200 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle1( 444, 444 )
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare )	

	// Accesing Java Classes Inside Kotlin
	//		Java 1.6 Onwards Is Compatible With Kotlin
	val random = Random()
	val rectangle3 = Rectangle1( random.nextInt(), random.nextInt() )
	println( rectangle3.width )
	println( rectangle3.height )
	println( rectangle3.isSquare )	
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Colour Type
//		Range = { RED, GREEN, BLUE }

enum class Colour {
	RED, GREEN, BLUE, YELLOW
}

// error: type mismatch: inferred type is String but Unit was expected
// fun getStringForColour1( colour: Colour ) {
// 	return when( colour ) {
// 		Colour.RED 		-> "It's Red Colour"
// 		Colour.GREEN 	-> "It's Green Colour"
// 		Colour.BLUE 	-> "It's Blue Colour"
// 	}
// }

// fun getStringForColour( colour: Colour ) {
fun getStringForColour( colour: Colour ) : String {
	return when( colour ) {
		Colour.RED 		-> "It's Red Colour"
		Colour.GREEN 	-> "It's Green Colour"
		// error: 'when' expression must be exhaustive, 
		// 		add necessary 'BLUE' branch or 'else' branch instead
		Colour.BLUE 	-> "It's Blue Colour"
		Colour.YELLOW 	-> "It's Yellow Colour"
		// Use else Choice As A Last Design Choice
		//		Rather Prefer Always Exaustive Cases
		// else 			-> "It's Uknown Colour"
	}
}

// fun getStringForColourAgain( colour: Colour ) : Unit = when( colour ) {
fun getStringForColourAgain( colour: Colour ) = when( colour ) {
	Colour.RED 		-> "It's Red Colour"
	Colour.GREEN 	-> "It's Green Colour"
	Colour.BLUE 	-> "It's Blue Colour"
	Colour.YELLOW 	-> "It's Yellow Colour"
}

fun playWithColours() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getStringForColour( Colour.RED ) )
	println( getStringForColour( Colour.GREEN ) )
	println( getStringForColour( Colour.BLUE ) )

	println( getStringForColourAgain( Colour.RED ) )
	println( getStringForColourAgain( Colour.GREEN ) )
	println( getStringForColourAgain( Colour.BLUE ) )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

//
// Color Type
//		Operation = { rgb() }
//		Range = { RED, GREEN, BLUE }

enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0) , GREEN(0, 255, 0), BLUE(0, 0, 255), YELLOW(0, 200, 200),
	ORANGE(200, 200, 0), INDIGO(100, 100, 100), VIOLET(50, 50, 50);

	fun rgb() = (r * 256 + g) * 256 + b
}

// In Kotlin
//		when Is Type Safe Expression
//		when ( EXPRESSION ) Here EXPRESSION can be any valid Kotlin Object
fun yeDilMangeeMore( color: Color ) = when( color ) {
	Color.RED 		-> "It's Red Color"
	Color.GREEN 	-> "It's Green Color"
	Color.BLUE 		-> "It's Blue Color"
	Color.YELLOW 	-> "It's Yellow Color"
	Color.ORANGE 	-> "It's Orange Color"
	Color.INDIGO 	-> "It's Indigo Color"
	Color.VIOLET 	-> "It's Violet Color"
}

fun playWithColors() {
	println( Color.RED )
	println( Color.GREEN )
	println( Color.BLUE )

	println( Color.RED.r )
	println( Color.RED.g )
	println( Color.RED.b )
	println( Color.GREEN.r )
	println( Color.GREEN.g )
	println( Color.GREEN.b )

	println( yeDilMangeeMore( Color.RED ) )
	println( yeDilMangeeMore( Color.GREEN ) )
	println( yeDilMangeeMore( Color.BLUE ) )

	println( Color.RED.rgb() )
	println( Color.GREEN.rgb() )
	println( Color.BLUE.rgb() )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun getWarmth(color: Color) = when(color) {
    Color.RED, Color.ORANGE, Color.YELLOW -> "warm"
    Color.GREEN -> "neutral"
    Color.BLUE, Color.INDIGO, Color.VIOLET -> "cold"
}

// when ( EXPRESSION ) Here EXPRESSION can be any valid Kotlin Object
fun mixColors(c1: Color, c2: Color) = when ( setOf(c1, c2) ) {
    setOf(Color.RED, Color.YELLOW) 	-> Color.ORANGE
    setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
    setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
    else -> throw Exception("Dirty Color")
}

fun mixColorsOptimized(c1: Color, c2: Color) = when {
    (c1 == Color.RED && c2 == Color.YELLOW)  || (c1 == Color.YELLOW && c2 == Color.RED) 	-> Color.ORANGE
    (c1 == Color.YELLOW && c2 == Color.BLUE) || (c1 == Color.BLUE && c2 == Color.YELLOW) 	-> Color.GREEN
    (c1 == Color.BLUE && c2 == Color.VIOLET) || (c1 == Color.VIOLET && c2 == Color.BLUE) 	-> Color.INDIGO
    else -> throw Exception("Dirty Color")
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Creating Type Expr
//		Operation = Range = Φ
interface Expr

// Creating Type Num
//		Operation = Φ
//		Range = Range Of Int
class Num( val value: Int ) : Expr

// Creating Type Sum
//		Operation = Φ
//		Range = Φ
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( e: Expr ) : Int {
	// Here :: What The Type Of e?
	//		e Type Is Expr
	// e is Num
	//		Type Check Of e
	//		e is Num == TRUE 
	//			Than e Will Be Type Casted To Num
	if ( e is Num ) { // Smart Type Casting
	// Here :: What The Type Of e?
	//		e Type Is Num
		return e.value
	}
	// Here :: What The Type Of e?
	//		e Type Is Expr
	if ( e is Sum ) {
	// Here :: What The Type Of e?
	//		e Type Is Sum
		return eval( e.left ) + eval( e.right )
	}
	// Here :: What The Type Of e?
	//		e Type Is Expr	
	throw IllegalArgumentException("Unknown Expression")
}

fun playWithEval() {
	var result: Int

	// 100 + 200
	result = eval( Sum( Num(100), Num(200)) )
	println("Result : $result")

	// ( 100 + 200 ) + 333
	result = eval( Sum( Sum( Num(100), Num(200)), Num( 333 )) )
	println("Result : $result")

	// ( ( 100 + 200 ) + ( 11 + 22 ) ) + 900 
	// ???????
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalAgain( e: Expr ) : Int {
	return if ( e is Num ) { 
		e.value
	} else  if ( e is Sum ) {
		evalAgain( e.left ) + evalAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression")
	}
}

fun evalOnceAgain( e: Expr ) : Int = if ( e is Num ) { 
		e.value
	} else  if ( e is Sum ) {
		evalOnceAgain( e.left ) + evalOnceAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvalOnceAgain() {
	var result: Int

	// 100 + 200
	result = evalOnceAgain( Sum( Num(100), Num(200)) )
	println("Result : $result")

	// ( 100 + 200 ) + 333
	result = evalOnceAgain( Sum( Sum( Num(100), Num(200)), Num( 333 )) )
	println("Result : $result")

	// ( ( 100 + 200 ) + ( 11 + 22 ) ) + 900 
	// ???????
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

 // error: type checking has run into a recursive problem.
// fun evalulate( expression: Expr ) = when ( expression ) {
fun evalulate( expression: Expr ) : Int = when ( expression ) {
 	is Num 	-> expression.value
	is Sum 	-> evalulate( expression.left ) + evalulate( expression.right )
	else  	-> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	var result: Int

	// 100 + 200
	result = evalulate( Sum( Num(100), Num(200)) )
	println("Result : $result")

	// ( 100 + 200 ) + 333
	result = evalulate( Sum( Sum( Num(100), Num(200)), Num( 333 )) )
	println("Result : $result")
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun fizzBuzz(i: Int) = when {  // Pattern Matching
    i % 15 == 0 -> "FizzBuzz "
    i % 3 == 0 -> "Fizz "
    i % 5 == 0 -> "Buzz "
    else -> "$i "
}

fun fizzyBuzzyThings() {
    for (i in 1..100) {
        print(fizzBuzz(i))
    }
}

fun rangesProgressions() {
    for (i in 100 downTo 1 step 2) {
        print(fizzBuzz(i))
    }
}   

fun isLetter(c: Char) 	= c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit(c: Char) = c !in '0'..'9'

fun usingInCheck() {
    println(isLetter('q'))
    println(isNotDigit('x'))
}

fun recognize(c: Char) = when (c) {
    in '0'..'9' -> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' -> "It's a letter!"
    else -> "I don't know..."
}

fun usingInCheckWithWhen() {
    println(recognize('8'))
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

//import java.util.TreeMap

fun iteratingOverMaps() {
    val binaryReps = TreeMap<Char, String>()

    for (character in 'A'..'F') {
        val binary = Integer.toBinaryString( character.code )
        binaryReps[ character ] = binary
    }

    for ((letter, binary) in binaryReps) {
        println("$letter = $binary")
    }
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________


fun main() {
	println("\nFunction : playWithHelloWorld")
	playWithHelloWorld()

	println("\nFunction : playWithMaximum")
	playWithMaximum()

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithTypeInferringAndBinding")
	playWithTypeInferringAndBinding()

	println("\nFunction : playWithRectangle")
	playWithRectangle()

	println("\nFunction : playWithRectangle1")
	playWithRectangle1();

	println("\nFunction : playWithColours")
	playWithColours()

	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalOnceAgain")
	playWithEvalOnceAgain()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : iteratingOverMaps")
	iteratingOverMaps()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//______________________________________________________________________
/*
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
*/
//______________________________________________________________________
