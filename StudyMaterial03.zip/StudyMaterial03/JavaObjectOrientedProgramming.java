/*
Compiling Java Source Code
	javac JavaObjectOrientedProgramming.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
	java -cp ClassFiles JavaObjectOrientedProgramming
*/


import java.time.DayOfWeek;
import java.time.LocalDate;

import java.util.ArrayList;

//______________________________________________________________________

// import java.time.DayOfWeek;
// import java.time.LocalDate;

// Assignment:Extend Following Code To Work Like cal Command
class Cal {
    public static void playWithCalender( String[] args ) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}


//______________________________________________________________________

// import java.util.ArrayList;

class Something {
	public static void doSomething() {
		ArrayList<String> friends = new ArrayList<>();
		friends.add("Peter");

		ArrayList<String> people = friends;
		people.add("Paul");
		
		System.out.println( friends );
		System.out.println( people );
	}
}

//______________________________________________________________________

class Employee {
	// Member Varibales Of Instance/Object
    private String name;
    private double salary;
    
    // Constructor
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    // Member Functions Of Instance/Object
    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

class EmployeeDemo {
    // Member Functions Of Class
    	
    public static void playWithEmployee() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);

        gabbar.raiseSalary( 50000 );
        System.out.println(gabbar.getName());
        System.out.println(gabbar.getSalary());

        Employee samba = new Employee("Samba", 5000);

        samba.raiseSalary( 0 );
        System.out.println(samba.getName());
        System.out.println(samba.getSalary());
    }
}
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

class JavaObjectOrientedProgramming {

	public static void main( String[] args ) {
	
		System.out.println("\nFunction: playWithCalender");
		Cal.playWithCalender( args );

		System.out.println("\nFunction: doSomething");
		Something.doSomething();

		System.out.println("\nFunction: playWithEmployee");
		EmployeeDemo.playWithEmployee();

		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}  
}

//______________________________________________________________________
//______________________________________________________________________

/*
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
*/

//______________________________________________________________________
//______________________________________________________________________
