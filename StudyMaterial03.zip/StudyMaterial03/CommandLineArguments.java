
public class CommandLineArguments {
	//						Command Line Arguments Are Passed To main Function
	public static void main( String[] args ) {

		for( int i = 0; i < args.length ; i++ ) {
			System.out.println( args[i] );

			// Based On Arguments 
			// Write Your Custom Logic Here...
		}
	}
}
