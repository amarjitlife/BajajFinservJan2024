/*
Compiling Java Source Code
javac JavaObjectOrientedProgramming.java -d ClassFiles

Invoking JVM, Loading Class File and Running It!
java -cp ClassFiles JavaObjectOrientedProgramming
*/

import java.time.DayOfWeek;
import java.time.LocalDate;

import java.util.ArrayList;

import java.util.Random;
import java.text.NumberFormat;


//______________________________________________________________________

// import java.time.DayOfWeek;
// import java.time.LocalDate;

// Assignment:Extend Following Code To Work Like cal Command
class Cal {
    public static void playWithCalender( String[] args ) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}


//______________________________________________________________________

// import java.util.ArrayList;

class Something {
	public static void doSomething() {
		ArrayList<String> friends = new ArrayList<>();
		friends.add("Peter");

		ArrayList<String> people = friends;
		people.add("Paul");
		
		System.out.println( friends );
		System.out.println( people );
	}
}

//______________________________________________________________________

class Employee {
	// Member Varibales Of Instance/Object
    private String name;
    private double salary;
    
    // Constructor
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    // Member Functions Of Instance/Object
    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

class EmployeeDemo {
    // Member Functions Of Class
    	
    public static void playWithEmployee() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);

        gabbar.raiseSalary( 50000 );
        System.out.println(gabbar.getName());
        System.out.println(gabbar.getSalary());

        Employee samba = new Employee("Samba", 5000);

        samba.raiseSalary( 0 );
        System.out.println(samba.getName());
        System.out.println(samba.getSalary());
    }
}

//______________________________________________________________________

// import java.util.Random;

class Employee1 {
    private String name = "";
    private double salary;
    private final int id;
        
    { // An initialization block
        Random generator = new Random(); 
        id = 1 + generator.nextInt(1_000_000);
    }
 
    // Overloading Constructor
    // ?????? 
    public  Employee1(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    
    // Overloading Constructor
    public Employee1(double salary) {
        // name already set to ""
        this.salary = salary;
    }        
    
    // Overloading Constructor
    public Employee1(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    // Overloading Constructor
    public Employee1() {
        this("", 0);
    }
            // ?????
    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }

    // public String dance(double salary) {
    //     // Some Logic Here...
    // }        

    // public double dance(double salary) {
    //     // Some Logic Here...
    // }        
}

class EmployeeDemo1 {
    public static void playWithConstructurOverloading() {
        Employee1 james = new Employee1("James Bond", 500000);

            // calls Employee1(String, double) constructor
        Employee1 anonymous = new Employee1("", 40000);

            // calls Employee1(double) constructor
        Employee1 unpaid = new Employee1("Igor Intern");

        Employee1 e = new Employee1();
            // no-arg constructor
    }
}

//______________________________________________________________________

// import java.text.NumberFormat;

// Creating Class/Type Members
class RandomNumbers {
    // Creating Class/Type Member Variable
    private static Random generator = new Random();
    
    // Creating Class/Type Member Function
    public static int nextInt(int low, int high) {
        return low + generator.nextInt(high - low + 1);
            // Ok to access the static generator variable
    }
}

class StaticMethodDemo {
    public static void playWithTypeMembers() {
        int dieToss = RandomNumbers.nextInt(1, 6); 
        System.out.println(dieToss);
        
        // Sending Message To Class/Type
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
        NumberFormat percentFormatter = NumberFormat.getPercentInstance();
        double x = 0.1;
        System.out.println(currencyFormatter.format(x)); // Prints $0.1        
        System.out.println(percentFormatter.format(x)); // Prints 10%
    }
}

//______________________________________________________________________

// import java.time.LocalDate;
// import java.util.ArrayList;

class CreditCardForm {
    private static final ArrayList<Integer> expirationYear = new ArrayList<>();

    // Initialistion Block For static Member Variables    
    static {
        // Add the next twenty years to the array list
        int year = LocalDate.now().getYear();
        for (int i = year; i <= year + 20; i++) {
            expirationYear.add(i);
        }   
    }
    // ...
}


//______________________________________________________________________
//______________________________________________________________________

// class Suit {

// }

// Defining Classes Inside Class
class Card {
    public class Suit {

    }

    Suit suit;
}


class CardDeck {
    // Defines Deck Of Card

    Card cards[];
}


//______________________________________________________________________
//______________________________________________________________________

class OuterClass { // Outsidside Class Context
    public String name = "OuterClass";

    // Define A Class Inside A Class
    //      By Default Inside Classes Are Inner Classes
    //      Inner Classes Can Acces Outer Class Context
    
    public class InsideClass { // Inside Class Context
        public void sayClass() {
            System.out.println("Say InsideClass Name: " + name );
        }
    }

    public InsideClass inside = new InsideClass();

    public void sayClass() {
        System.out.println("Say OuterClass Name: " + name );
    }
}

class OuterInsiderClassesDemo {
    public static void playWithOuterInsideClasses() {
        OuterClass outside = new OuterClass();
        outside.sayClass();

        outside.inside.sayClass();
    }    
}


//______________________________________________________________________

class OuterClassAgain { // Outsidside Class Context
    public String name = "OuterClass";

    // Define A Class Inside A Class
    //      Nested Class Inside Classes Are Inner Classes
    //      Nested Classes Can Acces Outer Class Context
    static public class InsideClass { // Inside Class Context
        public void sayClass() {
            // error: non-static variable name cannot be 
            //  referenced from a static context
            // System.out.println("Say InsideClass Name: " + name );
        }
    }

    public InsideClass inside = new InsideClass();

    public void sayClass() {
        System.out.println("Say OuterClass Name: " + name );
    }
}

class OuterInsiderClassesDemoAgain {
    public static void playWithOuterInsideClasses() {
        OuterClass outside = new OuterClass();
        outside.sayClass();

        outside.inside.sayClass();
    }    
}

//______________________________________________________________________

class Network {
    public class Member { // Member is an inner class of Network
        private String name;
        private ArrayList<Member> friends = new ArrayList<>();

        public Member(String name) {
            this.name = name;
        }

        public void deactivate() {
            members.remove(this);
        }

        public void addFriend(Member newFriend) {
            friends.add(newFriend);
        }

        public boolean belongsTo(Network n) {
            return Network.this == n;
        }
        
        public String toString() {
            StringBuilder result = new StringBuilder(name);
            result.append(" with friends ");
            for (Member friend : friends) {
                result.append(friend.name);
                result.append(", ");
            }
            return result.subSequence(0, result.length() - 2).toString();
        }
    }

    private ArrayList<Member> members = new ArrayList<>();

    public Member enroll(String name) {
        Member newMember = new Member(name);
        members.add(newMember);
        return newMember;
    }

    public String toString() {
        return members.toString();
    }
}

class NetworkDemo {
    public static void playWithInnerClasses() {
        Network myFace = new Network();
        Network tooter = new Network();
        Network.Member fred = myFace.enroll("Fred");
        Network.Member wilma = myFace.new Member("Wilma");
            // An object, but not enrolled
            // Make the constructor private to avoid this
        fred.addFriend(wilma);

        Network.Member barney = tooter.enroll("Barney");
        fred.addFriend(barney);
        System.out.println(myFace);
            // If it shouldn't be possible to add a friend
            // from another network, call belongsTo
        System.out.println(barney.belongsTo(myFace));
    }
}

//______________________________________________________________________

// import java.util.ArrayList;

class Invoice {
    // Defining Class Inside A Class
    private static class Item { // Item is nested inside Invoice
        String description;
        int quantity;
        double unitPrice;

        double price() { return quantity * unitPrice; }
    
        public String toString() { 
            return quantity + " x " + description + " @ $" + unitPrice + " each";
        }
    }

    private ArrayList<Item> items = new ArrayList<>();
    
    public void addItem(String description, int quantity, double unitPrice) {
        Item newItem = new Item();
        newItem.description = description;
        newItem.quantity = quantity;
        newItem.unitPrice = unitPrice;
        items.add(newItem);
    }
    
    public void print() {
        double total = 0;
        for (Item item : items) {
            System.out.println(item);
            total += item.price();
        }
        System.out.println( total );
    }
}

class InvoiceDemo {
    public static void playWithNestedClasses() {
        Invoice invoice = new Invoice();
        invoice.addItem("Blackwell Toaster", 2, 24.95);
        invoice.addItem("ZapXpress Microwave Oven", 1, 49.95);
        invoice.print();
    }
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

class JavaObjectOrientedProgramming {

	public static void main( String[] args ) {
	
		System.out.println("\nFunction: playWithCalender");
		Cal.playWithCalender( args );

		System.out.println("\nFunction: doSomething");
		Something.doSomething();

		System.out.println("\nFunction: playWithEmployee");
		EmployeeDemo.playWithEmployee();

		System.out.println("\nFunction: playWithConstructurOverloading");
        EmployeeDemo1.playWithConstructurOverloading();

		System.out.println("\nFunction: playWithTypeMembers");
        StaticMethodDemo.playWithTypeMembers();

		System.out.println("\nFunction: playWithOuterInsideClasses");
        OuterInsiderClassesDemo.playWithOuterInsideClasses();

		System.out.println("\nFunction: playWithOuterInsideClasses");
        OuterInsiderClassesDemoAgain.playWithOuterInsideClasses();

        System.out.println("\nFunction: playWithInnerClasses");
        NetworkDemo.playWithInnerClasses();

        System.out.println("\nFunction: playWithNestedClasses");
        InvoiceDemo.playWithNestedClasses();

        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
        // System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}  
}

//______________________________________________________________________
//______________________________________________________________________

/*
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
https://codebunk.com/b/4671100639098/
*/

//______________________________________________________________________
//______________________________________________________________________

