/**** Run Following Commands
kotlinc KotlinTypeNullability.kt -include-runtime -d nullability.jar
java -jar nullability.jar
****/
package learnKotlin

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithNullabilityAndNonNullability() {
	// String, Int, Float, Double etc... Are NON NULLABLE Types
	//		i.e. You CAN'T Assign null Value To These Types Variables
	var name: String = "Alice Carol"
	var age: Int = 30
	var occupation: String = "Software Engineer"

	println("$name $age $occupation")
	name = "Alice Carol Mcmillan"
	age = 40
	age = age + 1
	occupation = "Sr. Software Engineer"
	println("$name $age $occupation")	

	// Following 3 Lines Of Code Will Give Compilation Error
	// name = null  		// error: null can not be a value of a non-null type String
	// age = null 	 		// error: null can not be a value of a non-null type Int
	// occupation = null 	// error: null can not be a value of a non-null type String

	// Nullabe Types Are Also Called Optional Types
	// String?, Int?, Float?, Double? etc... Are NULLABLE Types
	//		i.e. You CAN Assign null Value To These Types Variables
	var name1: String? = "Alice Carol"
	var age1: Int? = 30
	var occupation1: String? = "Software Engineer"

	println("$name1 $age1 $occupation1")
	name1 = "Alice Carol Mcmillan"
	age1 = 40
	age1 = age1 + 1
	occupation1 = "Sr. Software Engineer"
	println("$name1 $age1 $occupation1")	

	name1 = null  		
	age1 = null 	 	
	occupation1 = null 	
	println("$name1 $age1 $occupation1")
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!


fun playWithNullabilityAndNonNullabilityAgain() {
	var authorName: String? = "Joe Howard"
	var authorAge: Int? = 24

	println(authorName)
	println(authorAge)

	// error: operator call corresponds to a dot-qualified call 
	// 'authorAge.plus(1)' which is not allowed on a nullable receiver 'authorAge'.
	// val ageAfterBirthday = authorAge + 1 	// authorAge.plus(1)

	// error: only safe (?.) or 
	// non-null asserted (!!.) calls are allowed on a 
	// nullable receiver of type Int?
	// ?. is Safe Calls Operator

	// Good Practice
	// if ( authorAge != null )
	// 	val ageAfterBirthday = authorAge.plus(1)
	// else
	// 	val ageAfterBirthday = null

	// BAD Practice
	// val ageAfterBirthday = authorAge.plus(1)

	val ageAfterBirthday0 = authorAge?.plus(1)
   // if ( authorAge != null )
	// 	val ageAfterBirthday = authorAge.plus(1)
	// else
	// 	val ageAfterBirthday = null

	println("After their next birthday, author will be $ageAfterBirthday0")

	// !! Not Recommended,  It's Used In Rarest Rare Scenarios 
	val ageAfterBirthday1 = authorAge!! + 1    
	println("After their next birthday, author will be $ageAfterBirthday1")

	authorAge = null
	println("After two birthdays, author will be $authorAge")
	// val ageAfterBirthday2 = authorAge!! + 1    

	var nonNullableAuthor: String = ""
	var nullableAuthor: String? = ""

	if (authorName != null) {
		nonNullableAuthor = authorName
	} else {
		nullableAuthor = authorName
	}

	println(nonNullableAuthor)
	println(nullableAuthor)

	// Nullable Types Members Cann't Be Accessed Using . Operator
	//		Use ?. or !! Operator

	// error: only safe (?.) or non-null asserted (!!.) calls are allowed 
	// on a nullable receiver of type String?
	// var nameLength = authorName.length
 
	// ?. is Safe Calls Operator
	var nameLength = authorName?.length
	// Above Line Of Code Is Equvalent To Following Line Of Code
	// 		if (authorName != null) authorName else null
	println("Author's name has length $nameLength.")

	val nameLengthPlus5 = authorName?.length?.plus(5)
	// Compiler Will Generate Following Code For Above Line  
	// if ( authorName != null ) {
	// 	if ( authorName.length != null ) {
	// 		nameLengthPlus5 = authorName.length.plus(5)
	// 	} else {
	// 		nameLengthPlus5 = null
	// 	}
	// } else {
	// 	nameLengthPlus5 = null
	// }
	println("Author's name length plus 5 is $nameLengthPlus5.")
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main( ) {
	println("\nFunction : playWithNullabilityAndNonNullability")
	playWithNullabilityAndNonNullability()

	println("\nFunction : playWithNullabilityAndNonNullabilityAgain")
	playWithNullabilityAndNonNullabilityAgain()

	// println("\nFunction : playWithElvisOperator")
	// playWithElvisOperator()

	// println("\nFunction : playWithCollectionNullability")
	// playWithCollectionNullability()

	// println("\nFunction : playWithNullabilityExperiments")
	// playWithNullabilityExperiments()

	// println("\nFunction : plaWithEmployeeManager")
	// plaWithEmployeeManager()

	// println("\nFunction : playWithPersonCountry")
	// playWithPersonCountry()

	// println("\nFunction : playWithPersonSafeTypeCast")
	// playWithPersonSafeTypeCast()

	// println("\nFunction : playWithExplicitTypeCasting")
	// playWithExplicitTypeCasting()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//_____________________________________________________
//_____________________________________________________

/*
https://codebunk.com/b/8211100641452/
https://codebunk.com/b/8211100641452/
https://codebunk.com/b/8211100641452/
https://codebunk.com/b/8211100641452/
*/

//_____________________________________________________
//_____________________________________________________

