/*
// Compiling Kotlin Code
kotlinc KotlinClassesMore.kt -include-runtime -d classes.jar

// Running Jar(Java Archive) File
java -jar classes.jar
*/
//______________________________________________________________________
package learnKotlin

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Towards Mutability
//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// In Kotlin
//		Classes Are Final By Default, So It Can't Be Inherited From
//		Members Are Also Final By Default

// In Java/C++
//		Classes Are Open By Default, So It Can Be Inherited From
//		Members Are Also Open By Default

open class Person( val firstName: String, val lastName: String ) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"

	override fun toString() = "Person(firstName=$firstName, lastName=$lastName)"
}

// error: 'firstName' hides member of supertype 'Person' and needs 'override' modifier
// error: 'lastName' hides member of supertype 'Person' and needs 'override' modifier
// class Student( val firstName: String, val lastName: String ) : Person( firstName, lastName )
data class Subject(val name: String, val grade: Char, val points: Double,
				   val credits: Double )
// Student Constructor
//		Takes Two Arguments Of String Type
//		Student Class Constructor Not Redefining/Defining firstName and lastName
//			i.e. Not Using val/var Before Name
//		Rather Reusing firstName and lastName Already Defined Person Class
open class Student( firstName: String, lastName: String ) : Person( firstName, lastName ) {
	val passedSubjects : MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects : MutableList<Subject> = mutableListOf<Subject>()	

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	}

	open fun printGrades() {
		for ( subject in passedSubjects ) println("	$subject")
		for ( subject in failedSubjects ) println("	$subject")
	}

	open fun isPassed() : Boolean {
		return failedSubjects.size <= 2
	}

	override fun toString() = "Student(firstName=$firstName, lastName=$lastName)"
}

fun playWithClassInheritance() {
	val gabbar = Person("Gabbar", "Singh")
	println( gabbar.fullName )
	println( gabbar )

	val sambha = Student("Sambha", "Side Kick")
	println( sambha.fullName )
	println( sambha )
}

fun playWithStudentGrades() {
	val alina = Student("Alina", "Mark")
	println( alina )
						// Named Arguments
	val alinaEnglish = Subject(name = "English", grade = 'C', points = 7.0, 
																credits = 3.0 )
	val alinaSc = Subject("Science", 'B', points = 8.0, credits = 4.0 )
	val alinaMaths = Subject("Mathematics", 'A', 9.0, 4.0)

	alina.recordGrade( alinaEnglish )
	alina.recordGrade( alinaSc )
	alina.recordGrade( alinaMaths )
	println( alina.fullName )
	alina.printGrades()
	println( "Passed : ${ alina.isPassed() }" )

	val gabbar = Student("Gabbar", "Singh")
	println( gabbar )

	val gabbarDecoit = Subject(name = "Decoit", grade = 'A', points = 10.0, 
															credits = 3.0 )
	val gabbarKidnapping = Subject(name = "Kidnapping", grade = 'A', points = 10.0,
															credits = 4.0 )
	val gabbarShooting = Subject(name = "Shooting", grade = 'A', points = 10.0,
															credits = 4.0 )
	gabbar.recordGrade( gabbarDecoit )
	gabbar.recordGrade( gabbarKidnapping )
	gabbar.recordGrade( gabbarShooting )
	println( gabbar.fullName )
	gabbar.printGrades()

	println( "Passed : ${ gabbar.isPassed() }" )
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

data class Game(val name: String, val grade: Char, val points: Double)

class StudentAthlete(firstName: String, lastName: String) : Student(firstName, lastName) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGame(game: Game) { gamesPlayed.add(game) }

	override fun printGrades() {
		super.printGrades()

		for ( game in gamesPlayed ) println("	$game")
	}

	override fun isPassed() : Boolean {
		return failedSubjects.size <= 1
	}
}

fun playWithStudentSportspersons() {
	val alina = StudentAthlete("Alina", "Mark")
	println( alina )
						// Named Arguments
	val alinaEnglish = Subject(name = "English", grade = 'C', points = 7.0, 
																credits = 3.0 )
	val alinaSc = Subject("Science", 'B', points = 8.0, credits = 4.0 )
	val alinaMaths = Subject("Mathematics", 'A', 9.0, 4.0)
	val alinaTennis = Game(name = "Tennis", grade = 'A', points = 9.0 )

	alina.recordGrade( alinaEnglish )
	alina.recordGrade( alinaSc )
	alina.recordGrade( alinaMaths )
	alina.recordGame( alinaTennis )
	println( alina.fullName )
	alina.printGrades()
	println( "Passed : ${ alina.isPassed() }" )

	val gabbar = StudentAthlete("Gabbar", "Singh")
	println( gabbar )
	val gabbarDecoit = Subject(name = "Decoit", grade = 'A', points = 10.0, credits = 3.0 )
	val gabbarKidnapping = Subject(name = "Kidnapping", grade = 'A', points = 10.0, credits = 4.0 )
	val gabbarShooting = Game(name = "Shooting", grade = 'A', points = 10.0)
	val gabbarHorseRiding = Game(name = "Horse Riding", grade = 'A', points = 10.0)

	gabbar.recordGrade( gabbarDecoit )
	gabbar.recordGrade( gabbarKidnapping )
	gabbar.recordGame( gabbarShooting )
	gabbar.recordGame( gabbarHorseRiding )

	println( gabbar.fullName )
	gabbar.printGrades()
	println( "Passed : ${ gabbar.isPassed() }" )
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!


open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 4 }
}

class FlutePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 3 }
}

fun playWithRuntimeTypeCheck() {
	val guitarPlayer : GuitarPlayer = GuitarPlayer("Arjit", "Singh")
	println( guitarPlayer )

	println( guitarPlayer is GuitarPlayer )
	println( guitarPlayer is BandMember )
	println( guitarPlayer is Student )
	println( guitarPlayer is Person )

	// guitarPlayer Object Is Of Type GuitarPlayer, BandMember, Student and Person Types
	var reference1: GuitarPlayer = guitarPlayer
	var reference2: BandMember = guitarPlayer
	var reference3: Student    = guitarPlayer
	var reference4: Person     = guitarPlayer

	println( reference1 is GuitarPlayer )
	println( reference1 is BandMember )
	println( reference1 is Student )
	println( reference1 is Person )

	println( reference2 is GuitarPlayer )
	println( reference2 is BandMember )
	println( reference2 is Student )
	println( reference2 is Person )	

	val bandMember : BandMember = BandMember("Varun", "Dhawan")
	println( bandMember )

	// error: type mismatch: inferred type is BandMember but GuitarPlayer was expected
	// reference1 = bandMember
	reference2 = bandMember
	reference3 = bandMember
	reference4 = bandMember

	println( reference2 is GuitarPlayer )
	println( reference2 is BandMember )
	println( reference2 is Student )
	println( reference2 is Person )	

	println( reference3 is GuitarPlayer )
	println( reference3 is BandMember )
	println( reference3 is Student )
	println( reference3 is Person )

	val sakira = BandMember("Sakira","Nagpal")
	println( sakira is GuitarPlayer )
	println( sakira is BandMember )
	println( sakira is Student )
	println( sakira is Person )	

	val milkha = StudentAthlete("Milkha", "Singh")
// : error: incompatible types: GuitarPlayer and StudentAthlete
	// println( milkha is GuitarPlayer )
// : error: incompatible types: BandMember and StudentAthlete
	// println( milkha is BandMember )
	println( milkha is StudentAthlete )
	println( milkha is Student )
	println( milkha is Person )	
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// error: abstract function 'consumeFood' in non-abstract class 'Mammal'
abstract class Mammal( val name: String, val birthData: String ) {
	// error: function 'consumeFood' without a body must be abstract
	abstract fun consumeFood(food: String)
}

class Human( name: String, birthData: String ) : Mammal( name, birthData ) {
	override fun consumeFood( food: String ) {
		println("Human Consuming Food!!!:: $food")
	}

	fun createBirthCertificate() = println("Birth Certificate Create with DOB: $birthData")
}

fun playWithMammals() {
	// error: cannot create an instance of an abstract class
	// val lalu = Mammal("Lalu Prasad Yadav", "10-10-10" )

	val lalu = Human("Lalu Prasad Yadav", "10-10-10")
	lalu.createBirthCertificate()
	lalu.consumeFood("Chaara")

	val keerty = Human("Keerty Suresh", "17-10-1992" )
	println( keerty is Human )
	println( keerty is Mammal )
}


//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Clickable3 {
    fun click()
    fun showOff() = println("I'm clickable!")
}

interface Focusable3 {
    fun setFocus(b: Boolean) =
        println("I ${if (b) "got" else "lost"} focus.")

    fun showOff() = println("I'm focusable!")
}

class Button3 : Clickable3, Focusable3 {
    override fun click() = println("I was clicked")

    override fun showOff() {
        super<Clickable3>.showOff()
        super<Focusable3>.showOff()
    }
}

fun playWithInterfacesAndRuntimeTypeCheck() {
	val button = Button3()

	println( button is Button3 )
	println( button is Clickable3 )
	println( button is Focusable3 )
}


//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

sealed class Geometry {
	class Circle(val radius: Int) : Geometry()
	class Square(val side: Int) : Geometry()
	class Unknown(val size: Int) : Geometry()
}

// Following Both Functions Are Same.
fun sizeOfGeometry1( geometry : Geometry ) : Any {
	return when( geometry ) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.side
		else -> "Unknown Shape"
	}
}

fun sizeOfGeometry2( geometry : Geometry ) = when( geometry ) {
	is Geometry.Circle -> geometry.radius
	is Geometry.Square -> geometry.side
	else -> "Unknown Shape"
}

fun sizeOfGeometry3( geometry : Geometry ) : Int {
	return when( geometry ) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.side
		is Geometry.Unknown -> geometry.size
		// else -> -1
	}
}

fun playWithGeometries() {
	val circle1 = Geometry.Circle( 10 )
	val square1 = Geometry.Square( 11 )
	println( sizeOfGeometry1( circle1 ) )
	println( sizeOfGeometry1( square1 ) )

	val circle2 = Geometry.Circle( 20 )
	val square2 = Geometry.Square( 22 )

	println( sizeOfGeometry2( square2 ) )
	println( sizeOfGeometry2( circle2 ) )

	println( sizeOfGeometry3( square2 ) )
	println( sizeOfGeometry3( circle2 ) )
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Primary and Secondary Constructors
// Following Both Definitions Are Same
				  // Primary Constructor
class PersonAgain1(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"
}

//				   constructor Keyword is Optional For Primary Constructor
class PersonAgain2 constructor(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"
}

fun playWithConstructors() {
	val person1 = PersonAgain1("Gabbar", "Singh")
	println( person1.fullName )

	val person2 = PersonAgain2("Gabbar", "Singh")
	println( person2.fullName )
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

open class Shape {
	var boundaryColor : String
	var fillColor : String

	// Secondary Constructors
	constructor( boundaryColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
	}

	// Overloading Secondary Constructor
	constructor( boundaryColor : String, fillColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
	}

	open fun printData() {
		println("Shape :: BoundryColor= $boundaryColor, FillColor = $fillColor")
	}
}

fun playWithShape() {
	val shape1 = Shape("Black")
	shape1.printData()

	val shape2 = Shape("Black", "Green")
	shape2.printData()
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Circle : Shape {
	var radius : Int

	// constructor( boundaryColor : String ) : super( boundaryColor ) {
	constructor( boundaryColor : String ) : this( boundaryColor, "Unknown", 0 ) {
	// constructor( boundaryColor : String ) {
		// error: explicit 'this' or 'super' call is required. 
		// There is no constructor in superclass that can be called without arguments\
		// NOTE :: Following Is Redundunt Code If Following Constructor Called
		//		this( boundaryColor, "Unknown", 10 )
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
		this.radius = 0
	}

	constructor( boundaryColor : String, fillColor: String, radius: Int ) : super(boundaryColor, fillColor) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
		this.radius = radius
	}

	override fun printData() {
		println("Circle :: BoundryColor= $boundaryColor, FillColor = $fillColor, Radius = $radius")
	}
}

fun playWithShapeAndCircle() {
	val circle1 = Circle("Black")
	circle1.printData()

	// val circle2 = Circle("Black", "Red")
	// circle2.printData()

	val circle3 = Circle("Black", "Green", 10)
	circle3.printData()
}


//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithLocalFunctionsAndClasses() { //Outside Function/Context
	// Local Function
	//		Function Defined Inside Function
	//		doSomething Is Local Function
	var something = 10
	fun doSomething() { //Inside Function/Context
		println("Local Function doSomething Called...")
		println("Accessing Inside : $something")
		something = 1111
	}

	// println("Accessing Outside : $something")
	// Local Classes
	//		Class Defined Inside Function
	//		Person Is Local Class To Function

	//Inside Class/Context
	class Person(val firstName: String, val lastName: String) { 
		val somethingAgain = something + 100

		fun doDance() = println("$firstName $lastName Doing Dance...")
		fun doSomething() {
			println("Accessing Inside Person: $somethingAgain")
			something = somethingAgain
		}
	}

	doSomething()
	println("Accessing Outside : $something")

	val person = Person("Gabbar", "Singh")
	println( person.firstName )
	println( person.lastName )
	person.doDance()
	person.doSomething()
	println("Accessing Outside : $something")
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

data class Privilege( val id: Int, val name: String )
// Property Visibility
//     Default Visibility Is Public i.e. Accessible Inside and Outside Of Defining Class
//     Private Visibility Accessible Only Inside Defining Class
//     Protected Visibility Accessible Inside Defining Class And Child Classes Of It
open class User(val firstName: String, val lastName: String, protected var age: Int, private var aadharCard: Int ) 

class PrivilegedUser(firstName: String, lastName: String, age: Int, aadharCard: Int) : User(firstName, lastName, age, aadharCard) {
    // Private To PrivilegeUser Class Only
    //      Cann't Be Accessed Outside Using Object Of PrivilegeUser Class
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add( privilege )
    }

    fun printPrivileges() {
        for ( privilege in privileges ) {
            println( "    $privilege" )
        }
    }

    fun details() : String {
        // error: cannot access 'aadharCard': 
        // it is invisible (private in a supertype) in 'PrivilegedUser'
        // return "$firstName $lastName $aadharCard"

        return "Name : $firstName $lastName, Age: $age"
    }
}

fun playWithPrivilegedUser() {
    val privilegedUser = PrivilegedUser(firstName = "Alice", lastName = "Carols", age = 21, aadharCard = 9999 )
    val invisiblePrivilege = Privilege( id = 11, name = "Can Become Invisible")
    val immortalPrivilege  = Privilege( id = 22, name = "Can Become Immortal")
    privilegedUser.addPrivilege( invisiblePrivilege )
    privilegedUser.addPrivilege( immortalPrivilege )
    println( privilegedUser.details() )
    privilegedUser.printPrivileges()
    // println( privilegedUser.privileges )
    // privilegedUser.privileges.add( Privilege( -99, "Something Useless Power"))
    // println( privilegedUser.privileges )
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// In Kotlin
//		Class Defined Inside Class Are Nested Class By Default

// In Java
//		Class Defined Inside Class Are Inner Class By Default

class Car(val carName: String) { // Outside Class/Context
	val steering: Int = 0

	// Defining Nested Class Engine
	//		A Class Defined Inside Class
	//			Are Nested Class By Default In Kotlin
	//			Indide Class/Context CAN'T Access Outside Class/Context
	class Engine(val engineName: String) { // Inside Class/Context
		override fun toString() : String {
			// error: unresolved reference: carName
			// return "Car $carName Have Engine $engineName"
			return "Car Have Engine $engineName"
		}
	}
} 

class CarAgain(val carName: String) { // Outside Class/Context
	val steering: Int = 0

	// Defining Inner Class Engine
	//		A Class Defined Inside Class
	//			Indide Class/Context CAN Access Outside Class/Context
	inner class Engine(val engineName: String) { // Inside Class/Context
		override fun toString() : String {
			// error: unresolved reference: carName
			return "Car $carName Have Engine $engineName"
			// return "Car Have Engine $engineName"
		}
	}
} 

fun playWithNestedAndInnerClasses() {
	val harrier = Car("Avantador")
	val harrierEngine = Car.Engine("V12") 

	println( harrierEngine ) // harrierEngine.toString()

	val swift = CarAgain("Swift Dzire")
	val swiftEngine = swift.Engine("Fiat")

	println( swiftEngine ) // swiftEngine.toString()	
}

//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
//______________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!


fun main() {
	println("\nFunction : playWithClassInheritance")
	playWithClassInheritance()

	println("\nFunction : playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction : playWithStudentSportspersons")
	playWithStudentSportspersons()

	println("\nFunction : playWithRuntimeTypeCheck")
	playWithRuntimeTypeCheck()

	println("\nFunction : playWithMammals")
	playWithMammals()

	println("\nFunction : playWithInterfacesAndRuntimeTypeCheck")
	playWithInterfacesAndRuntimeTypeCheck()

	println("\nFunction : playWithConstructors")
	playWithConstructors()

	println("\nFunction : playWithShape")
	playWithShape()

	println("\nFunction : playWithShapeAndCircle")
	playWithShapeAndCircle()

	println("\nFunction : playWithLocalFunctionsAndClasses")
	playWithLocalFunctionsAndClasses()

	println("\nFunction : playWithPrivilegedUser")
	playWithPrivilegedUser()

	println("\nFunction : playWithNestedAndInnerClasses")
	playWithNestedAndInnerClasses()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//______________________________________________________________________
//______________________________________________________________________

/*
https://codebunk.com/b/8211100641452/
https://codebunk.com/b/8211100641452/
https://codebunk.com/b/8211100641452/
https://codebunk.com/b/8211100641452/
*/

//______________________________________________________________________
//______________________________________________________________________

