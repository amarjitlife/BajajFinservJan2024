
//______________________________________________________________________
//
// DAY 01
//______________________________________________________________________

	Assignment D01.A1 : Reading Thinking and Experimentation Assignments

		The C Programming Language, 2nd Edition
			Kernigham and Dennish Ritchie

			Chapter 2 - Types, Operators and Expressions 
			Chapter 3 - Control Flow

		Thinking and Experimentation Assignments
			In C/C++/Java/Python/JavaScript
			1. Explore Divide By Zero Behaviour 
			2. Explore Comparison Of float and double Type Data
//______________________________________________________________________
//
// DAY 02
//______________________________________________________________________

	Assignment D02.A0 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D02.A1 : Foundation Assignments Assignments
		Reference Book:
			The C Programming Language, 2nd Edition
				Kernigham and Dennish Ritchie

		Read Following Chapters Thoroughly and Experiment
			Chapter 2 - Types, Operators and Expressions [ MUST MUST ]
			Chapter 3 - Control Flow
			Chapter 5 - Pointers And Arrays [ MUST MUST MUST ]

	Assignment D02.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment
			Chapter 1 - Fundamental Programming Structures		

	Assignment D02.A3 : Coding, Design and Reasoning Assignment

		Thinking and Experimentation Assignments
			In C/C++/Java/Python/JavaScript
			1. Explore Divide By Zero Behaviour 
			2. Explore Comparison Of float and double Type Data
			3. Calculate Factorial Of Any Whole Number

	Assignment D02.A4 : Reading Documentation Assignment
		https://docs.oracle.com/javase/8/docs/api/java/lang/String.html


	Assignment D02.A5 : In Depth Reading Assignment
		WhatEveryProgrammerShouldKnowAboutFloatingPoints.pdf
	
//______________________________________________________________________
//
// DAY 03
//______________________________________________________________________

	Assignment D03.A0 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D03.A1 : Foundation Assignments Assignments
		Reference Book:
			The C Programming Language, 2nd Edition
				Kernigham and Dennish Ritchie

		Read Following Chapters Thoroughly and Experiment
			Chapter 2 - Types, Operators and Expressions [ MUST MUST ]
			Chapter 5 - Pointers And Arrays [ MUST MUST MUST ]

	Assignment D03.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment
			Chapter 1 - Fundamental Programming Structures		
			Chapter 2 - Object Oriented Programming

	Assignment D03.A3 : Coding, Design and Reasoning Assignment

		Thinking and Experimentation Assignments
			In C/C++/Java/Python/JavaScript
			1. Explore Divide By Zero Behaviour 
			2. Explore Comparison Of float and double Type Data
			3. Calculate Factorial Of Any Whole Number
			4. Where Is main Function Call. How Command Line Arguments Works?
			5. How Varidiac Arguments Works Internally
			6. Simulate 2D Array in C Using Only Pointers

	Assignment D03.A4 : Reading Documentation Assignment
		https://docs.oracle.com/javase/8/docs/api/java/lang/String.html

	Assignment D03.A5 : In Depth Reading Assignment
		WhatEveryProgrammerShouldKnowAboutFloatingPoints.pdf


//______________________________________________________________________
//
// DAY 04
//______________________________________________________________________

	Assignment D04.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D04.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment
			Chapter 1 - Fundamental Programming Structures		
			Chapter 2 - Object Oriented Programming
			Chapter 3 - Interfaces and Lambdas

//______________________________________________________________________
//
// DAY 05
//______________________________________________________________________

	Assignment D05.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D05.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment
			Chapter 3 - Interfaces and Lambdas
			Chapter 4 - Inheritance and Reflections
			Chapter 5 - Exceptions, Assertions and Logging
			Chapter 6 - Generic Programming

//______________________________________________________________________
//
// DAY 06
//______________________________________________________________________

	Assignment D06.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D06.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment
			Chapter 3 - Interfaces and Lambdas
			Chapter 4 - Inheritance and Reflections
			Chapter 5 - Exceptions, Assertions and Logging
			Chapter 6 - Generic Programming

//______________________________________________________________________
//
// DAY 07
//______________________________________________________________________

	Assignment D07.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D07.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 4 - Inheritance and Reflections
			Chapter 5 - Exceptions, Assertions and Logging
			Chapter 6 - Generic Programming

	Assignment D07.A3 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 1 - Kotlin What And Why?


//______________________________________________________________________
//
// DAY 08 :: CHALLENGE ACCEPTED BY YOUNG TEAM 
//______________________________________________________________________

	Assignment D08.A0 : REVISION ASSIGNMENT
		Reference Book:
			The C Programming Language, 2nd Edition
				Kernigham and Dennish Ritchie

		Read Following Chapters Thoroughly and Experiment
			Chapter 5 - Pointers And Arrays [ MUST MUST MUST ]

	Assignment D08.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D08.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 5 - Exceptions, Assertions and Logging
			Chapter 6 - Generic Programming
			Chapter 7 - Collections
			Chapter 8 - Streams

	Assignment D08.A3 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 1 - Kotlin What And Why?
			Chapter 2 - Kotlin Basics
			Chapter 3 - Kotlin Functions

//______________________________________________________________________
//
// DAY 09 :: CHALLENGE ACCEPTED BY YOUNG TEAM 
//______________________________________________________________________

	Assignment D08.A0 : REVISION ASSIGNMENT
		Reference Book:
			The C Programming Language, 2nd Edition
				Kernigham and Dennish Ritchie

		Read Following Chapters Thoroughly and Experiment
			Chapter 5 - Pointers And Arrays [ MUST MUST MUST ]

	Assignment D08.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D08.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 5 - Exceptions, Assertions and Logging
			Chapter 6 - Generic Programming
			Chapter 7 - Collections
			Chapter 8 - Streams

	Assignment D08.A3 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 1 - Kotlin What And Why?
			Chapter 2 - Kotlin Basics
			Chapter 3 - Kotlin Functions

	Reference: Kotlin String Functions
		String Library
		https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/

//______________________________________________________________________
//
// DAY 10 
//______________________________________________________________________

	Assignment D08.A0 : REVISION ASSIGNMENT
		Reference Book:
			The C Programming Language, 2nd Edition
				Kernigham and Dennish Ritchie

		Read Following Chapters Thoroughly and Experiment
			Chapter 5 - Pointers And Arrays [ MUST MUST MUST ]

	Assignment D08.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D08.A2 : Reading Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 5 - Exceptions, Assertions and Logging
			Chapter 6 - Generic Programming
			Chapter 7 - Collections
			Chapter 8 - Streams

	Assignment D08.A3 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 1 - Kotlin What And Why?
			Chapter 2 - Kotlin Basics
			Chapter 3 - Kotlin Functions

	Reference: Kotlin String Functions
		String Library
		https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/

//______________________________________________________________________
//
// DAY 11 
//______________________________________________________________________

	Assignment D11.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D11.A2 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 5 - Programming With Lambdas
			Chapter 8 - Higher-Order Functions
			Chapter 4 - Classes, Objects and Interfaces


//______________________________________________________________________
//
// DAY 12 
//______________________________________________________________________

	Assignment D12.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D12.A2 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 4 - Classes, Objects and Interfaces
			Chapter 5 - Programming With Lambdas
			Chapter 7 - Operator Overloading and Conventions
			Chapter 8 - Higher-Order Functions

	Assignment D12.A3 : REVISION Assignment In Java
		Reference Book: 
			Core Java for the Impatient By Cay S. Horstmann

		Revise Following Chapters Thoroughly and Experiment Code
			Chapter 3 - Interfaces and Lambdas
			Chapter 6 - Generic Programming

	Assignment D12.A4 : Setup Android Environment
		In Your Personal Machines
		

//______________________________________________________________________
//
// DAY 13 
//______________________________________________________________________

	Assignment D13.A1 : Coding and Experiementation Assignment
		Experiment All The Code Done Till Now

	Assignment D13.A2 : Reading Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Read Following Chapters Thoroughly and Experiment Code
			Chapter 7 - Operator Overloading and Conventions
			Chapter 8 - Higher-Order Functions

	Assignment D13.A3 : REVISION Assignment In Kotlin
		Reference Book: 
			Kotlin In Action By Dmitry Jemerov and Svetlana Isakova

		Revise Following Chapters Thoroughly and Experiment Code
			Chapter 4 - Classes, Objects and Interfaces
			Chapter 5 - Programming With Lambdas

	Assignment D13.A4 : Setup Android Environment
		In Your Personal Machines
		
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________


