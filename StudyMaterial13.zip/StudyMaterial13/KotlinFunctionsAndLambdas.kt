package learnKotlin

/*
// Compiling Kotlin Code
kotlinc KotlinFunctionsAndLambdas.kt -include-runtime -d functions.jar

// Running Jar(Java Archive) File
java -jar functions.jar
*/

//______________________________________________________________________

import java.util.Random
import java.util.TreeMap

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// NOTE: Write Good Code... In Below Functions

// Following Functions Have Type
//	Function Type: (Int, Int) -> Int
//		Function Which Takes (Int, Int) -> Int
fun sum( a: Int, b: Int ) = a + b
fun sub( a: Int, b: Int ) = a - b
fun mul( a: Int, b: Int ) = a * b
fun div( a: Int, b: Int ) = a / b  
fun sum3( a: Int, b: Int, c: Int ) = a + b + c

// Higher Order Function
//		Functions Which Takes Function As Argument 
//			AND/OR
//		Returns Function

// calculator Is Higher Order Function
//		It Takes Function As Argument 

// Polymorphic Function: Achieving Polymorhism 
//		Mechanism: Using Passing Behaviour/Function To A Function

//	Function Type: (Int, Int, (Int, Int) -> Int ) -> Int
//		Function Which Takes 2 Arguments and Returns Int Type Value
///		1st Argument Type: Int
//		2nd Argument Type: Int
//		3rd Argument Type: (Int, Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result : Int

	result = calculator( a, b, ::sum )
	println("Result = $result")

	result = calculator( a, b, ::sub )
	println("Result = $result")

	result = calculator( a, b, ::mul )
	println("Result = $result")

	result = calculator( a, b, ::div )
	println("Result = $result")

	// var something: Int = ::sum
	// ::sum Is Reference Of sum Function
	//		::sum Reference Is Of Type (Int, Int) -> Int
	var something: (Int, Int) -> Int = ::sum
	println("Something... = $something")
	result = something( 88, 11 )
	println("Result = $result")

	var somethingAgain: (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	println("Something Again... = $somethingAgain")

	result = somethingAgain( a, b, ::mul )
	println("Result = $result")	

	//	Lambda Expression
	//		Which Take Two Int Arguments and Return Int Type Value
	// 		Lambda Expression Used
	//			To Define Single Code i.e. Simple Functions/Logic
	val sumLambda = { x: Int, y: Int -> x + y }
	val sumLambdaAgain: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator( a, b, sumLambda )
	println("Result = $result")
	result = calculator( a, b, sumLambdaAgain )
	println("Result = $result")
	result = calculator( a, b, { x: Int, y: Int -> x + y } )
	println("Result = $result")

	val subLambda = { x: Int, y: Int -> x - y }
	val subLambdaAgain: (Int, Int) -> Int = { x: Int, y: Int -> x - y }
	result = calculator( a, b, subLambda )
	println("Result = $result")
	result = calculator( a, b, subLambdaAgain )
	println("Result = $result")
	result = calculator( a, b, { x: Int, y: Int -> x - y } )
	println("Result = $result")
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// Creating NumberType
//		Range = { ZERO, EVEN, ODD }
enum class NumberType { NONZERO, ZERO, EVEN, ODD, PRIME, NOTPRIME }

fun checkZero( number : Int ) : NumberType {
	return if ( number == 0 ) NumberType.ZERO else NumberType.NONZERO
}

fun checkEven( number : Int ) : NumberType {
	return if ( number % 2  == 0 ) NumberType.EVEN  else NumberType.ODD
}

fun checkPrime( number : Int ) : NumberType {
	// Write Better Logic To Check Number Is Prime Or Not
	return if ( number == 0 ) NumberType.PRIME else NumberType.NOTPRIME
}

// Higher Order Function
fun checkNumber( number: Int, check: (Int) -> NumberType ) : NumberType {
	return check(number)
}

// Higher Order Function
fun printDataAndChecks( numbers: Array<Int>, checks: Array<(Int) -> NumberType> ) {
	for ( number in numbers ) {
		println( number )
	}

	for ( check in checks  ) {
		println( check )
	}
}

fun checkData( numbers: Array<Int>, checks: Array<(Int) -> NumberType> ) {
	for ( number in numbers ) {
		for ( check in checks  ) {
			println( checkNumber( number, check ) )
		}
	}
}

fun playWithNumbersType( ) {
	// DATA
	val numbers = arrayOf(99, 0, 100, 10, 88, 11, 77, 22, 0)
	val checks: Array<(Int) -> NumberType> = arrayOf( ::checkZero, ::checkEven, ::checkPrime )

	// Checking Data
	checkData( numbers, checks )
	printDataAndChecks( numbers, checks )
}


//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun summation( a: Int, b: Int ) = a + b
fun summation3( a: Int, b: Int, c: Int ) = a + b + c

fun playWithFunctionsAgain() {
	var something = ::summation
	// var somethingAgain: (Int, Int) -> Int = ::summation

	var result = something(100, 200)
	println("\nResult = $result")

	// error: type mismatch: inferred type is KFunction2<Int, Int, Int> 
	// but KFunction3<Int, Int, Int, Int> was expected
	// something = ::summation3
	// result = something(100, 200, 300)
	// println("\nResult = $result")
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

data class Person(val name: String, val age: Int)

fun filterData(persons: List<Person>) {
	var maxAge = 0
	var theOldest: Person? = null

	for( person in persons ) {
		if ( person.age > maxAge ) {
			maxAge = person.age
			theOldest = person 
		}
	}
	println( theOldest )
}

fun playWithFilterData() {
	val persons = listOf( Person("Gabbar Singh", 35), Person("Basanti", 24),
	 					  Person("Veeru", 27), Person("Jay", 25) )
	filterData( persons )
}


// Filter Persons Data Based On Criterias 
//		Only age, Only grade, Only id


fun filterAgain1(persons: List<Person>) {
	var max = 0
	var selectedPerson: Person? = null

	for( person in persons ) {
		if ( person.age > max ) {
			max = person.age
			selectedPerson = person 
		}
	}
	println( selectedPerson )
}

/*
fun filterAgain2(persons: List<Person>) {
	var max = 0
	var selectedPerson: Person? = null

	for( person in persons ) {
		if ( person.grade > max ) {
			max = person.grade
			selectedPerson = person
		}
	}
	println( selectedPerson )
}

fun filterAgain3(persons: List<Person>) {
	var max = 0
	var selectedPerson: Person? = null

	for( person in persons ) {
		if ( person.id > max ) {
			max = person.id
			selectedPerson = person
		}
	}
	println( selectedPerson )
}
*/

data class Person1(val name: String, val age: Int, val grade: Int, val id: Int)

fun transformToId( person: Person1 ) : Int {	
	return person.id
}

fun transformToAge( person: Person1 ) : Int {	
	return person.age
}

fun transformToGrade( person: Person1 ) : Int {	
	return person.grade
}

// Polymorphic Function
//		Higher Order Function
//			Takes Function As Argument
fun filter( persons: List<Person1>, transform: (Person1) -> Int  ) {
	var max = 0
	var selectedPerson: Person1? = null
	var select: Int

	for( person in persons ) {
		select = transform( person )
		if ( select > max ) {
			max = select
			selectedPerson = person
		}
	}
	println( selectedPerson )
}

fun playWithFilterAgain() {
	val persons = listOf( 
		Person1("Gabbar Singh", 35, 5, 420), 
		Person1("Basanti", 24, 4, 500),
		Person1("Veeru", 27, 7, 120), 
		Person1("Jay", 25, 4, 200) 
	)

	filter( persons,  ::transformToId )
	filter( persons,  transform = { person: Person1 -> person.id } )
	filter( persons,  ::transformToAge )
	filter( persons ) { 
		person: Person1 -> person.age 
	} 
	
	filter( persons,  ::transformToGrade )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithLambdas() {
	// What Is Type Of something
	val something = { println(42) }
	// val something: () -> Unit = { println(42) }
	something()

	val persons = listOf( Person("Alice", 20), Person("Gabbar", 35), 
		Person("Basanti", 24), Person("Veeru", 27), Person("Jay", 25) )

	val names = persons.joinToString( 
						separator = " ", 
						transform = { person: Person -> person.name } 
					)
	println(names)

	var lambdaResult: Int
	var multiplyLambda : (Int, Int) -> Int

	val multiplyLambda0 = { a: Int, b: Int -> a * b }
	// val multiplyLambda0: (Int, Int) -> Int = { a: Int, b: Int -> a * b }

	lambdaResult = multiplyLambda0( 10, 20 )
	println( lambdaResult )

	multiplyLambda = { a: Int, b: Int -> Int
		a * b
	}

	lambdaResult = multiplyLambda( 10, 20 )
	println( lambdaResult )

	multiplyLambda = { a, b -> 
		a * b
	}

	lambdaResult = multiplyLambda( 10, 20 )
	println( lambdaResult )

	var doubleLamda = { a: Int -> a * 2 }
	// var doubleLamda: (Int) -> Int = { a: Int -> a * 2 }

	lambdaResult = doubleLamda( 25 )
	println( lambdaResult )

	doubleLamda = { it * 2 }
	lambdaResult = doubleLamda( 25 )
	println( lambdaResult )

	val square1 = { number : Int -> number * number }
	// val square1: (Int) -> Int = { number : Int -> number * number }

	lambdaResult = square1( 25 )
	println( lambdaResult )

	// val square2 = { it * it }
	val square2: (Int) -> Int = { it * it }
	lambdaResult = square2( 25 )
	println( lambdaResult )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

fun playWithLambdasAgain() {
	var result : Int

	// Higher Order Functions
	//		Function Which Takes Function Argument
	fun operate(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
		val result = operation(a, b)
		return result
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operate( 40, 20, operation = addLambda )
	println( result )

	fun addFunction(a: Int, b: Int) = a + b
	result = operate( 40, 20, operation = ::addFunction )
	println( result )	

	result = operate( 40, 20, operation = Int::plus )
	println( result )	

	result = operate( 40, 20, operation = { a: Int, b: Int -> a + b } )
	println( result )	

	result = operate( 40, 20, 
		operation = { a: Int, b: Int -> 
			a + b 
		} 
	)
	println( result )	

	result = operate( 40, 20, 
		operation = { a, b -> 
			a + b 
		} 
	)
	println( result )

	result = operate( 40, 20, operation = { a, b -> a + b } )
	println( result )	

	result = operate( 40, 20, { a, b -> a + b } )
	println( result )	

	// Trailing Lambda
	result = operate( 40, 20 ) { a, b -> a + b } 
	println( result )	
			 // operate Function Logic
	result = operate( 40, 20 ) { // Extended By Custom Logic 
		a, b -> a + b 
	} 
	println( result )
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

// What Is The Type Of Followings
// 		Function Type :: (Boolean) -> (Int) -> Int
fun chooseSteps(backward: Boolean) : (Int) -> Int {
	var gabbar = 420
	// What Is The Type Of Followings
	//		Function Type :: (Int) -> Int
	fun moveForward(start: Int) : Int { return gabbar + start + 1 }
	fun moveBackward(start: Int): Int { return gabbar + start - 1 }

	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepFunction() {
	// What Is The Type Of Followings
	val something = chooseSteps( backward = true )
	var somethingAgain = ::chooseSteps

	val somethingMore = something(10)
	println( somethingMore )
	
	val somethingOnceMore = somethingAgain(true)
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun printMessageWithPrefix( messages: Collection<String>, prefix: String ) {
	messages.forEach {
		println("$prefix $it")
	}
}

fun playWithPrintMessages() {
	val errors = listOf("404 Not Found", "403 Forbidden")
	printMessageWithPrefix( errors, "Error: ")
}

//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!
//______________________________________________________________________
// COMPLETE FOLLOWING CODE HANDS ON! MOMENT DONE RAISE YOUR FLAG!!!

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithNumbersType")
	playWithNumbersType()

	println("\nFunction : playWithFunctionsAgain")
	playWithFunctionsAgain()

	println("\nFunction : playWithFilterData")
	playWithFilterData()

	println("\nFunction : playWithFilterAgain")
	playWithFilterAgain()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	println("\nFunction : playWithLambdasAgain")
	playWithLambdasAgain()

	println("\nFunction : playWithChooseStepFunction")
	playWithChooseStepFunction()

	println("\nFunction : playWithPrintMessages")
	playWithPrintMessages()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//______________________________________________________________________
//______________________________________________________________________
/*
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
https://codebunk.com/b/2251100640038/
*/
//______________________________________________________________________
//______________________________________________________________________
