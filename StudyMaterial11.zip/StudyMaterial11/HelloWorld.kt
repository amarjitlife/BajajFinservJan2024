package learnKotlin

/*
// Compiling Kotlin Code
kotlinc HelloWorld.kt -include-runtime -d hello.jar

// Running Jar(Java Archive) File
java -jar hello.jar
*/

fun helloWorld() {
	println("Hello World! Welcome To Kotlin!!!!")
}

fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
// Kotlinc Compiler Will Generate Following Code
//		To Make It Compatible With JVM/Java
public class HelloWorldKt {
	public static void helloWorld() {
		println("Hello World! Welcome To Kotlin!!!!");
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction : helloWorld");
		helloWorld();
	}
}
*/


